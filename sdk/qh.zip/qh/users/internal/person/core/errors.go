package person

import (
	"errors"
)

var (
	ErrPersonExists = errors.New("person exits")
)
