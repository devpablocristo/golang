// TODO:migrations deberia estar por entidad tb? o moverlo a algun lado? mmmmm no se

DROP TABLE events;
