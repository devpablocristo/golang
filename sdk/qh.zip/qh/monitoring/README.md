grafana, prometheus y pprof
revisar kong


solo con fines de estudio, eliminar y configurar metricas y monitorizacion para cada ms