package csdgocsl

type CassandraConfig struct {
	Hosts    []string
	Keyspace string
	Username string
	Password string
}
