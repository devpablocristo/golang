package gingonic

type GinConfig struct {
	RouterPort string
}
