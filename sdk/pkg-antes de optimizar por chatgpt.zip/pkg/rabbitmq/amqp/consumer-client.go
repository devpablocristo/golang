package messaging

import (
	"fmt"
	"log"
	"sync"

	"github.com/streadway/amqp"
)

var (
	consumerInstance BrokerConsumerPort
	consumerOnce     sync.Once
	consumerErr      error
)

// BrokerConsumerPort define la interfaz para consumir mensajes.
type BrokerConsumerPort interface {
	Consume(queueName string, handler func(amqp.Delivery)) error
	Close()
}

// RabbitMQConsumer implementa la interfaz BrokerConsumerPort.
type RabbitMQConsumer struct {
	connection *amqp.Connection
	channel    *amqp.Channel
}

// InitializeRabbitMQConsumer crea una nueva instancia de RabbitMQConsumer usando el patrón singleton.
func InitializeRabbitMQConsumer(uri string) error {
	consumerOnce.Do(func() {
		client := &RabbitMQConsumer{}
		consumerErr = client.connect(uri)
		if consumerErr != nil {
			consumerInstance = nil
		} else {
			consumerInstance = client
		}
	})
	return consumerErr
}

// GetRabbitMQConsumerInstance devuelve la instancia del RabbitMQConsumer.
func GetRabbitMQConsumerInstance() (BrokerConsumerPort, error) {
	if consumerInstance == nil {
		return nil, fmt.Errorf("RabbitMQConsumer: client is not initialized")
	}
	return consumerInstance, nil
}

// connect establece la conexión con RabbitMQ.
func (con *RabbitMQConsumer) connect(uri string) error {
	conn, err := amqp.Dial(uri)
	if err != nil {
		return fmt.Errorf("failed to connect to RabbitMQ: %v", err)
	}

	ch, err := conn.Channel()
	if err != nil {
		return fmt.Errorf("failed to open a channel: %v", err)
	}

	con.connection = conn
	con.channel = ch
	log.Println("RabbitMQConsumer connected successfully")
	return nil
}

// Consume inicia el consumo de mensajes desde una cola específica en RabbitMQ.
func (con *RabbitMQConsumer) Consume(queueName string, handler func(amqp.Delivery)) error {
	msgs, err := con.channel.Consume(
		queueName,
		"",    // Consumer
		true,  // Auto-Ack
		false, // Exclusive
		false, // No-local
		false, // No-Wait
		nil,   // Args
	)
	if err != nil {
		return fmt.Errorf("failed to register a consumer: %v", err)
	}

	go func() {
		for msg := range msgs {
			handler(msg)
			log.Printf("Message consumed from queue %s", queueName)
		}
	}()

	return nil
}

// Close cierra la conexión y el canal de RabbitMQ.
func (con *RabbitMQConsumer) Close() {
	err := con.channel.Close()
	if err != nil {
		log.Printf("Error closing channel: %v", err)
	}
	err = con.connection.Close()
	if err != nil {
		log.Printf("Error closing connection: %v", err)
	}
}
