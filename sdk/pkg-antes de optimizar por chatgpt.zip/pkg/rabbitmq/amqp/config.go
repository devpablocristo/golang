package messaging

import "fmt"

// RabbitMQConfig representa la configuración para conectar con RabbitMQ.
type RabbitMQConfig struct {
	URI       string // Dirección del servidor de RabbitMQ
	QueueName string // Nombre de la cola para enviar/recibir mensajes
	Username  string // Nombre de usuario para autenticación (opcional)
	Password  string // Contraseña para autenticación (opcional)
}

// Validate verifica que la configuración de RabbitMQ esté completa.
func (config RabbitMQConfig) Validate() error {
	if config.URI == "" || config.QueueName == "" {
		return fmt.Errorf("incomplete RabbitMQ configuration: URI and QueueName are required")
	}
	return nil
}

// String devuelve una representación en cadena de la configuración.
func (config RabbitMQConfig) String() string {
	return fmt.Sprintf("RabbitMQConfig{URI: %s, QueueName: %s}", config.URI, config.QueueName)
}
