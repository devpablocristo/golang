package messaging

import (
	"fmt"
	"log"
	"sync"

	"github.com/streadway/amqp"
)

var (
	publisherInstance BrokerPublisherPort
	publisherOnce     sync.Once
	publisherErr      error
)

// BrokerPublisherPort define la interfaz para publicar mensajes.
type BrokerPublisherPort interface {
	Publish(queueName string, body []byte) error
	Close()
}

// RabbitMQPublisher implementa la interfaz BrokerPublisherPort.
type RabbitMQPublisher struct {
	connection *amqp.Connection
	channel    *amqp.Channel
}

// InitializeRabbitMQPublisher crea una nueva instancia de RabbitMQPublisher usando el patrón singleton.
func InitializeRabbitMQPublisher(uri string) error {
	publisherOnce.Do(func() {
		client := &RabbitMQPublisher{}
		publisherErr = client.connect(uri)
		if publisherErr != nil {
			publisherInstance = nil
		} else {
			publisherInstance = client
		}
	})
	return publisherErr
}

// GetRabbitMQPublisherInstance devuelve la instancia del RabbitMQPublisher.
func GetRabbitMQPublisherInstance() (BrokerPublisherPort, error) {
	if publisherInstance == nil {
		return nil, fmt.Errorf("RabbitMQPublisher: client is not initialized")
	}
	return publisherInstance, nil
}

// connect establece la conexión con RabbitMQ.
func (pub *RabbitMQPublisher) connect(uri string) error {
	conn, err := amqp.Dial(uri)
	if err != nil {
		return fmt.Errorf("failed to connect to RabbitMQ: %v", err)
	}

	ch, err := conn.Channel()
	if err != nil {
		return fmt.Errorf("failed to open a channel: %v", err)
	}

	pub.connection = conn
	pub.channel = ch
	log.Println("RabbitMQPublisher connected successfully")
	return nil
}

// Publish envía un mensaje al broker de RabbitMQ.
func (pub *RabbitMQPublisher) Publish(queueName string, body []byte) error {
	queue, err := pub.channel.QueueDeclare(
		queueName,
		true,  // Durable
		false, // Delete when unused
		false, // Exclusive
		false, // No-wait
		nil,   // Arguments
	)
	if err != nil {
		return fmt.Errorf("failed to declare a queue: %v", err)
	}

	err = pub.channel.Publish(
		"",         // Exchange
		queue.Name, // Routing key
		false,      // Mandatory
		false,      // Immediate
		amqp.Publishing{
			ContentType: "text/plain",
			Body:        body,
		})
	if err != nil {
		return fmt.Errorf("failed to publish a message: %v", err)
	}

	log.Printf("Message published to queue %s", queueName)
	return nil
}

// Close cierra la conexión y el canal de RabbitMQ.
func (pub *RabbitMQPublisher) Close() {
	err := pub.channel.Close()
	if err != nil {
		log.Printf("Error closing channel: %v", err)
	}
	err = pub.connection.Close()
	if err != nil {
		log.Printf("Error closing connection: %v", err)
	}
}
