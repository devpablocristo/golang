#!/usr/bin/bash
# doenst work with zsh

protoc chat.proto --go_out=plugins=grpc:.