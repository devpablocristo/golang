package domain

type User struct {
	ID   string
	Type string // person, persons group, company, companies grupo, or any mix
}
