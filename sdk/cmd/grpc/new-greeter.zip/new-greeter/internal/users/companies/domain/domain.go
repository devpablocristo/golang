package domain

type Company struct {
	Name string
}
