package port

type Service interface{}

type Repo interface{}
