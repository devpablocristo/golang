package report

import (
	"context"
)

type RepositoryPort interface {
	CreateReport(context.Context, string) error
}
