package core

import (
	"context"

	"github.com/devpablocristo/events-sn/analytics/internal/core/report"
)

type UseCasePort interface {
	CreateReport(context.Context, report.Report) error
}
