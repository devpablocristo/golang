package analytics

import "time"

type AnalyticsReport struct {
	ReportID    string
	GeneratedAt time.Time
	Metrics     map[string]interface{}
}
