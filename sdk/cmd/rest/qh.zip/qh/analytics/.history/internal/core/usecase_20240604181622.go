package core

import (
	"context"

	ltp "github.com/devpablocristo/events-sn/analytics/internal/core/ltp"
	"github.com/devpablocristo/events-sn/analytics/internal/core/report"
)

type UseCase struct {
	ltp     ltp.RepositoryPort
	reports report.RepositoryPort
}

func NewUseCase(r ltp.RepositoryPort) UseCasePort {
	return &UseCase{
		ltp: r,
	}
}

func (u *UseCase) CreateReport(ctx context.Context, report []report.Report) error {
	return nil
}
