package core

import (
	"context"
)

type UseCasePort interface {
	CreateReport(context.Context) error
}
