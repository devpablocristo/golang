package core

import (
	"context"
)

type UseCasePort interface {
	GetLTP(context.Context) error
}
