package core

import (
	"context"

	ltp "github.com/devpablocristo/events-sn/analytics/internal/core/ltp"
)

type UseCase struct {
	ltp ltp.RepositoryPort
}

func NewUseCase(r ltp.RepositoryPort) UseCasePort {
	return &UseCase{
		ltp: r,
	}
}

func (u *UseCase) CreateReport(ctx context.Context, report []Report) error {
	return nil
}
