package handler

import (
	"net/http"

	"github.com/gin-gonic/gin"

	ucs "github.com/devpablocristo/events-sn/analytics/internal/core"

	tst "github.com/devpablocristo/events-sn/analytics/cmd/api/tests"
)

type RestHandler struct {
	ucs ucs.UseCasePort
}

func NewRestHandler(ucs ucs.UseCasePort) *RestHandler {
	return &RestHandler{ucs: ucs}
}

func (h *RestHandler) FakeCreateReport(c *gin.Context) {
	c.JSON(http.StatusOK, "loading...\n\n\n")

	rep, err := tst.LoadTestData()
	if err != nil {
		c.JSON(http.StatusInternalServerError, err.Error())
		return
	}

	c.JSON(http.StatusOK, gin.H{"report": rep})
}
