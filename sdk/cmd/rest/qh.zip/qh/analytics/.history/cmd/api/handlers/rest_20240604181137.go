package handler

import (
	"encoding/json"
	"net/http"

	"github.com/gin-gonic/gin"

	tst "github.com/devpablocristo/events-sn/analytics/cmd/api/tests"
	ucs "github.com/devpablocristo/events-sn/analytics/internal/core"
)

type RestHandler struct {
	ucs ucs.UseCasePort
}

func NewRestHandler(ucs ucs.UseCasePort) *RestHandler {
	return &RestHandler{
		ucs: ucs,
	}
}

func (h *RestHandler) FakeCreateReport(c *gin.Context) {
	data, err := tst.LoadTestData()
	if err != nil {
		c.JSON(http.StatusInternalServerError, err.Error())
		return
	}

	var metricsList EventMetricsDTO
	
	if err := json.Unmarshal(data, &metricsList), err != nil {
		c.JSON(http.StatusInternalServerError, err.Error())
		return
	}

	err = h.ucs.CreateReport(c.Request.Context(), metricsList.ToDomain())
	if err != nil {
		c.JSON(http.StatusInternalServerError, err.Error())
		return
	}

	c.JSON(200, gin.H{"message": "Report received"})
}

func (h *RestHandler) FakeCreateReport(c *gin.Context) {
    data, err := tst.LoadTestData()
    if handleError(c, err) {
        return
    }

    var metricsList EventMetricsDTO
    if err := json.Unmarshal(data, &metricsList); handleError(c, err) {
        return
    }

    if err := h.ucs.CreateReport(c.Request.Context(), metricsList.ToDomain()); handleError(c, err) {
        return
    }

    c.JSON(http.StatusOK, gin.H{"message": "Report received"})
}

func handleError(c *gin.Context, err error) bool {
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return true
    }
    return false
}
