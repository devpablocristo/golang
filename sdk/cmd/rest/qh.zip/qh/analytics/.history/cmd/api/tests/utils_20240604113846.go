package tests

import (
	"encoding/json"
	"os"
	"path/filepath"
	"runtime"
)

// LoadTestData carga datos de prueba desde un archivo JSON.
func LoadTestData() ([]report.reportReport, error) {
	// Define el path absoluto al archivo JSON.
	_, b, _, _ := runtime.Caller(0)
	basePath := filepath.Dir(b)
	filePath := filepath.Join(basePath, "test-data", "report_data.json")

	data, err := os.ReadFile(filePath)
	if err != nil {
		return nil, err
	}

	var reports []report.reportReport
	err = json.Unmarshal(data, &reports)
	if err != nil {
		return nil, err
	}

	return reports, nil
}
