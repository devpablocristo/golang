package handler

import (
	"time"

	"github.com/devpablocristo/events-sn/analytics/internal/core/report"
)

type EventMetricsDTO struct {
	EventMetrics []EventReportDTO `json:"eventMetrics"`
}

type EventReportDTO struct {
	EventID   string `json:"eventId"`
	EventName string `json:"eventName"`
	Visits    int    `json:"visits"`
}

func DTOToDomain(dto EventMetricsDTO) ([]report.Report, error) {
	reports := make([]Report, len(dto.EventMetrics))
	for i, eventReportDTO := range dto.EventMetrics {
		report := Report{
			ReportID:    generateReportID(), // Implement logic to generate a unique report ID
			GeneratedAt: time.Now(),
			Metrics: map[string]interface{}{
				"eventId":   eventReportDTO.EventID,
				"eventName": eventReportDTO.EventName,
				"visits":    eventReportDTO.Visits,
			},
		}
		reports[i] = report
	}

	return reports, nil
}
