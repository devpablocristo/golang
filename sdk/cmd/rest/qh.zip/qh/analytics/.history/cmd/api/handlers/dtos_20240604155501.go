package handler

type EventDTO struct {
	EventID   string `json:"eventId"`
	EventName string `json:"eventName"`
	Visits    int    `json:"visits"`
}
