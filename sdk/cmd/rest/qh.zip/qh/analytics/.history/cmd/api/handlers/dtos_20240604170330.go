package handler

type EventMetricsDTO struct {
	EventMetrics []EventReportDTO `json:"eventMetrics"`
}

type EventReportDTO struct {
	EventID   string `json:"eventId"`
	EventName string `json:"eventName"`
	Visits    int    `json:"visits"`
}
