package handler

import (
	"github.com/devpablocristo/events-sn/analytics/internal/core/report"
)

type EventMetricsDTO struct {
	EventMetrics []EventReportDTO `json:"eventMetrics"`
}

type EventReportDTO struct {
	EventID   string `json:"eventId"`
	EventName string `json:"eventName"`
	Visits    int    `json:"visits"`
}

func (ems EventMetricsDTO) ToDomain() report.Report {
	var report report.Report
	for _, eventReportDTO := range ems.EventMetrics {
		report = report.Report{
			Metrics: map[string]interface{}{
				"eventId":   eventReportDTO.EventID,
				"eventName": eventReportDTO.EventName,
				"visits":    eventReportDTO.Visits,
			},
		}
	}

	return report
}
