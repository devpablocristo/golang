package handler

type EventMetricsDTO struct {
	EventMetrics []ReportDTO `json:"eventMetrics"`
}

type ReportDTO struct {
	EventID   string `json:"eventId"`
	EventName string `json:"eventName"`
	Visits    int    `json:"visits"`
}
