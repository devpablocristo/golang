package handler

import (
	"encoding/json"
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"

	tst "github.com/devpablocristo/events-sn/analytics/cmd/api/tests"
	ucs "github.com/devpablocristo/events-sn/analytics/internal/core"
)

type RestHandler struct {
	ucs ucs.UseCasePort
}

func NewRestHandler(ucs ucs.UseCasePort) *RestHandler {
	return &RestHandler{
		ucs: ucs,
	}
}

func (h *RestHandler) FakeCreateReport(c *gin.Context) {
	data, err := tst.LoadTestData()
	if err != nil {
		c.JSON(http.StatusInternalServerError, err.Error())
		return
	}

	//var metricsList EventMetricsDTO
	var metricsList []ReportDTO

	err = json.Unmarshal(data, &metricsList)
	if err != nil {
		c.JSON(http.StatusInternalServerError, err.Error())
		return
	}

	for _, report := range metricsList.EventMetrics {
		fmt.Printf("\n\n\nEvent ID: %s\nEvent name: %s\nEvent visits: %d\n\n\n", report.EventID, report.EventName, report.Visits)
	}

	c.JSON(200, gin.H{"message": "Report received"})
}
