package handler

import (
	"github.com/devpablocristo/events-sn/analytics/internal/core/report"
)

type EventMetricsDTO struct {
	EventMetrics []EventReportDTO `json:"eventMetrics"`
}

type EventReportDTO struct {
	EventID   string `json:"eventId"`
	EventName string `json:"eventName"`
	Visits    int    `json:"visits"`
}

func (ems *EventMetricsDTO) ToDomain() *report.Report {
	var report *report.Report
	report.Metrics = make(map[string]interface{})
	for _, eventReportDTO := range ems.EventMetrics {
		// Agregamos cada evento al mapa de métricas
		report.Metrics[eventReportDTO.EventID] = map[string]interface{}{
			"eventName": eventReportDTO.EventName,
			"visits":    eventReportDTO.Visits,
		}
	}
	return report
}
