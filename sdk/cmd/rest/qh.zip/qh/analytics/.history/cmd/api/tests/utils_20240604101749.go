package tests

import (
	"encoding/json"
	"io/ioutil"
	"path/filepath"
	"runtime"
)

// LoadTestData carga datos de prueba desde un archivo JSON.
func LoadTestData() ([]AnalyticsReport, error) {
	// Define el path absoluto al archivo JSON.
	_, b, _, _ := runtime.Caller(0)
	basePath := filepath.Dir(b)
	filePath := filepath.Join(basePath, "test-data", "analytics_data.json")

	data, err := ioutil.ReadFile(filePath)
	if err != nil {
		return nil, err
	}

	var reports []AnalyticsReport
	err = json.Unmarshal(data, &reports)
	if err != nil {
		return nil, err
	}

	return reports, nil
}
