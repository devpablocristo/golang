package tests

import (
	"encoding/json"
	"os"
	"path/filepath"
	"runtime"

	"github.com/devpablocristo/events-sn/analytics/internal/core/report"
)

type EventMetricsDTO struct {
	EventID   string `json:"eventId"`
	EventName string `json:"eventName"`
	Visits    int    `json:"visits"`
}

type EventMetricsListDTO struct {
	EventMetrics EventMetricsDTO `json:"eventMetrics"`
}

func LoadTestData() ([]report.Report, error) {
	_, b, _, _ := runtime.Caller(0)
	basePath := filepath.Dir(b)
	filePath := filepath.Join(basePath, "tests-data", "report-data.json")

	data, err := os.ReadFile(filePath)
	if err != nil {
		return nil, err
	}

	var eventMetrics EventMetricsListDTO
	err = json.Unmarshal(data, &eventMetrics)
	if err != nil {
		return nil, err
	}

	return eventMetrics.EventMetrics, nil
}
