package handler

type ReportDTO struct {
	EventID   string `json:"eventId"`
	EventName string `json:"eventName"`
	Visits    int    `json:"visits"`
}
