package handler

import (
	"github.com/gin-gonic/gin"

	ucs "github.com/devpablocristo/events-sn/analytics/internal/core"

	tst "github.com/devpablocristo/events-sn/analytics/cmd/api/tests"
)

type RestHandler struct {
	ucs ucs.UseCasePort
}

func NewRestHandler(ucs ucs.UseCasePort) *RestHandler {
	return &RestHandler{ucs: ucs}
}

func (h *RestHandler) FakeCreateReport(c *gin.Context) {
	tst.LoadTestData()

}
