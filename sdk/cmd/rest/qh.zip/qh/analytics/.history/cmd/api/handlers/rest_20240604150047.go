package handler

import (
	"fmt"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"

	ucs "github.com/devpablocristo/events-sn/analytics/internal/core"
	"github.com/devpablocristo/events-sn/analytics/internal/core/report"

	tst "github.com/devpablocristo/events-sn/analytics/cmd/api/tests"
)

type RestHandler struct {
	ucs ucs.UseCasePort
}

func NewRestHandler(ucs ucs.UseCasePort) *RestHandler {
	return &RestHandler{ucs: ucs}
}

func (h *RestHandler) FakeCreateReport(c *gin.Context) {
	//c.String(http.StatusOK, "loading...\n\n\n")

	rep, err := tst.LoadTestData()
	if err != nil {
		c.JSON(http.StatusInternalServerError, err.Error())
		return
	}

	//c.JSON(http.StatusOK, gin.H{"report": rep})

	var reports []report.Report
	if err := c.BindJSON(&rep); err != nil {
		c.JSON(400, gin.H{"error": err.Error()})
		return
	}

	// Haz lo que necesites con los informes aquí
	for _, report := range reports {
		fmt.Printf("ReportID: %s, GeneratedAt: %s\n", report.ReportID, report.GeneratedAt.Format(time.RFC3339))
		for key, value := range report.Metrics {
			fmt.Printf("Metric %s: %v\n", key, value)
		}
	}

	c.JSON(200, gin.H{"message": "Reports received"})
}
