package tests

import (
	"encoding/json"
	"os"
	"path/filepath"
	"runtime"

	"github.com/devpablocristo/events-sn/analytics/internal/core/analytics-report"
)

// LoadTestData carga datos de prueba desde un archivo JSON.
func LoadTestData() ([]analytics.AnalyticsReport, error) {
	// Define el path absoluto al archivo JSON.
	_, b, _, _ := runtime.Caller(0)
	basePath := filepath.Dir(b)
	filePath := filepath.Join(basePath, "test-data", "analytics_data.json")

	data, err := os.ReadFile(filePath)
	if err != nil {
		return nil, err
	}

	var reports []analytics.AnalyticsReport
	err = json.Unmarshal(data, &reports)
	if err != nil {
		return nil, err
	}

	return reports, nil
}
