package tests

import (
	"encoding/json"
	"os"
	"path/filepath"
	"runtime"
)

type EventDTO struct {
	EventID   string `json:"eventId"`
	EventName string `json:"eventName"`
	Visits    int    `json:"visits"`
}

func LoadTestData() ([]EventDTO, error) {
	_, b, _, _ := runtime.Caller(0)
	basePath := filepath.Dir(b)
	filePath := filepath.Join(basePath, "tests-data", "report-data.json")

	data, err := os.ReadFile(filePath)
	if err != nil {
		return nil, err
	}

	var events []EventDTO
	err = json.Unmarshal(data, &events)
	if err != nil {
		return nil, err
	}

	return events, nil
}
