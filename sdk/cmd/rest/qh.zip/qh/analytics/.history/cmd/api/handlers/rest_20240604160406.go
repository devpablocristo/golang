package handler

import (
	"encoding/json"
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"

	tst "github.com/devpablocristo/events-sn/analytics/cmd/api/tests"
	ucs "github.com/devpablocristo/events-sn/analytics/internal/core"
)

type RestHandler struct {
	ucs ucs.UseCasePort
}

func NewRestHandler(ucs ucs.UseCasePort) *RestHandler {
	return &RestHandler{ucs: ucs}
}

func (h *RestHandler) FakeCreateReport(c *gin.Context) {
	c.String(http.StatusOK, "loading...\n\n\n")

	data, err := tst.LoadTestData()
	if err != nil {
		c.JSON(http.StatusInternalServerError, err.Error())
		return
	}

	var reports []ReportDTO
	err = json.Unmarshal(data, &reports)
	if err != nil {
		c.JSON(http.StatusInternalServerError, err.Error())
		return
	}

	// var reports []report.Report
	// if err := c.BindJSON(&reports); err != nil {
	// 	c.JSON(400, gin.H{"error": err.Error()})
	// 	return
	// }

	for _, r := range reports {
		fmt.Printf("Event ID: %s, Event name: %s, Event visits: %d\n", r.EventID, r.EventName, r.Visits)
	}

	c.JSON(200, gin.H{"message": "Reports received"})
}
