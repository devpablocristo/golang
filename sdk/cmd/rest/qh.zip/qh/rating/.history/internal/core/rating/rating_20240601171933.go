package rating

type Rating struct {
	Item     string
	Score    int
	Comments string
}
