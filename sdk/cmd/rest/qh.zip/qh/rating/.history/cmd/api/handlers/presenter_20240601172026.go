package handler

import (
	"github.com/devpablocristo/qh/rating/internal/core/ltp"
	"github.com/devpablocristo/qh/rating/internal/core/rating"
)

type responseLTP struct {
	Pair   string  `json:"pair"`
	Amount float64 `json:"amount"`
}

func ToResponseLTP(l *ltp.LTP) *responseLTP {
	return &responseLTP{
		Pair:   l.Pair,
		Amount: l.Amount,
	}
}

func ToResponseLTPList(ltps []ltp.LTP) map[string][]responseLTP {
	ltpList := make([]responseLTP, len(ltps))
	for i, ltp := range ltps {
		ltpList[i] = *ToResponseLTP(&ltp)
	}
	return map[string][]responseLTP{"ltp": ltpList}
}

func ToRating(dto RatingDTO) *rating.Rating {
	return &rating.Rating{
		Item:     dto.Item,
		Score:    dto.Score,
		Comments: dto.Comments,
	}
}

func ToRatingDTO(r *rating.Rating) RatingDTO {
	return RatingDTO{
		ID:       r.ID,
		Item:     r.Item,
		Score:    r.Score,
		Comments: r.Comments,
	}
}
