package handlers

type RatingDTO struct {
	ID       int    `json:"id"`
	Item     string `json:"item"`
	Score    int    `json:"score"`
	Comments string `json:"comments"`
}
