package rating

type Rating struct {
	ID       int
	Item     string
	Score    int
	Comments string
}
