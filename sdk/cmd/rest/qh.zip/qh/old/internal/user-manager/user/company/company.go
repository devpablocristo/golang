package company

type Company struct {
	Name string
}
