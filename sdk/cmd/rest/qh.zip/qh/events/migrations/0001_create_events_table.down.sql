DROP TABLE events;
