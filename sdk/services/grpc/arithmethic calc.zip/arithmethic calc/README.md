# my-hexagonal-go
Of of most beautiful implementations of Hexagonal (Port-Adaptor based) Architecture using Golang, a gRPC/REST Arith Operations API

Packages and Libs used:

Squirrel
MySQL
Protobuf
LANN
Testify
Go-CMP
Go-Spew

$ mkdir -p ./{bin,src,pkg}

protoc --go-grpc_out=internal/adaptors/framework/left/grpc --proto_path=internal/adaptors/framework/left/grpc/proto internal/adaptors/framework/left/grpc/proto/*.proto

![1](images/1.png)
![2](images/2.png)
![3](images/3.png)
![4](images/4.png)
![5](images/5.png)
![6](images/6.png)
![7](images/7.png)
![8](images/8.png)
![9](images/9.png)
![10](images/10.png)
![11](images/11.png)
![12](images/12.png)
![13](images/13.png)
![14](images/14.jpg)
![15](images/15.png)
