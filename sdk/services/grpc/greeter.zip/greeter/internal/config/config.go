package config

// Define the port the server will listen on
const (
	GrpcServerPort = ":50051"
)
