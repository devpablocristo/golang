package rabbitmq
