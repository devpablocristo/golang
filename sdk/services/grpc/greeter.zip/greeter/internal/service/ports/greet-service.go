package port

type GreetService interface{}
