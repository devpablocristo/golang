

client usecases -> client -> server -> server usecases - server -> client -> client usecases