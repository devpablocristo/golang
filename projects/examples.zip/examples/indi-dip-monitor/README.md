El score comienza en 0, lo cual indica que no se han detectado violaciones de DIP (Dependency Inversion Principle).

Se incrementa el score en 1 punto por cada violación detectada.

El score ideal, es decir, la situación en la que no existen violaciones del principio DIP, es 0. 