package repository

//type PlaceRepository interface {
//	Insert(*models.Place) error
//	Update(string, *model.Place) error
//	Delete(string) error
//	FindByID(string) (*model.Place, error)
//	FindAll() ([]models.Place, error)error
//}
