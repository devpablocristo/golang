package main

import (
	"fmt"

	tinderpets "pets"
)

func main() {
	fmt.Println("hola")
	pet := tinderpets.Pet
}
