
0.1.0 / 2018-09-23
==================

  * Add mongodb integration
  * Create basic CRUD struct
  * Improvement on listenAndServe
  * Add simple main.go with mux
  * Add simple main.go
  * Add travis build icon on README
  * Add travis file
  * First commit files
