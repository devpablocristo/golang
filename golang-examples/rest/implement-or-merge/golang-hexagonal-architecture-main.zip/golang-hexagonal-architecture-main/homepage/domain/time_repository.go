package domain

type TimeRepository interface {
	GetTime() string
}
