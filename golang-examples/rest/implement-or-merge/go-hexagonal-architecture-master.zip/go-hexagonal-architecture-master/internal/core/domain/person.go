package domain

type Person struct {
	Id int
	Name string
}
