[![MIT License](http://img.shields.io/badge/license-MIT-blue.svg?style=flat)](LICENSE) [![Go Report Card](https://goreportcard.com/badge/github.com/mlabouardy/movies-restapi)](https://goreportcard.com/report/github.com/mlabouardy/movies-restapi)

RESTful API to manage movies written in Go and uses MongoDB as storage
