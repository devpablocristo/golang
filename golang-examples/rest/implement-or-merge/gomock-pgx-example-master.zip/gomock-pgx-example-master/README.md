# How to Mock Database with GoMock
For more information you can check out here: https://medium.com/@eftal/how-to-mock-database-with-gomock-9bd0a92ffc10
