package main

import "fmt"

func main() {
	fmt.Println("Conexión a MongoDB")
}
