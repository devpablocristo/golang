# Lista de recursos especificos el lenguaje

    lib: Librerias.
    cfg: Archivos de configuración.
    doc: Documentación.
    obs: Archivos obsoletos útiles.
    des: Descargas.
    pla: Plantillas.
