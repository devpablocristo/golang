# Welcome to the WeDevelop React challenge 🚀

## Requirements

1. Clone the project.
2. Use the existing project to complete the tasks.

### To config and run the project

```console
foo@bar:~$ npm install
foo@bar:~$ npm start
```

***Node.js version: 17.3.0***

## Happy Coding!
