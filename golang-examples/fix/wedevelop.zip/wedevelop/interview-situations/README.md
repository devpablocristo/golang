# interview-situations
Real-life situations that we use to evaluate our people or recruitees.
