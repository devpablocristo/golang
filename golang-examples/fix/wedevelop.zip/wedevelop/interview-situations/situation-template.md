# Situation template

Use this template to create new *situations*:

```
[title]

Description: [description]

Payload: [payload]...

Notes for interviewer:
- Evaluation method: [evaluation method]
- Positive response: [positive response]...
- Negative response: [negative response]...
- Extra points if: [extra point response]...

Situation metadata:
- Level: [situation level]
- Preferred technology / language: [preferred tech/lang]
- Other supported technologies / languages: [other techs/langs]
- Expected resolution time: [resolution time]
```

- **title**: Use a short and clear title that describes this situation.
- **description**: Describe in a few words, to the interviewee, what's the situation about. Please, include anything that the interviewee should know beforehand and state clearly what's the expected outcome for the situation.
- **payload**: Include any file, URL, document, or any other piece of data that's required to communicate the situation. It can be more than one.
- **notes for interviewer**: Please, include anything that the interviewer could find handy for the interview:
  - **evaluation method**: Explain to the interviewer what evaluation method should be used for this situation.
  - **positive response**: Describe what's the expected response to determine that the situation has been solved successfully.
  - **negative response**: OPTIONAL. Describe any response that should be considered a **RED FLAG** and therefore determine that the situation has NOT been solved successfully.
  - **extra point response**: OPTIONAL. Include any additional response that should be considered a "nice-to-have" and grant "extra points" to the interviewee.
- **situation level**: Range 0-5 where 0 is very simple (icebreaker) and 5 is very complex.
- **preferred tech/lang**: Optimal technology stack the interviewee should dominate to succeed on the situation.
- **other techs/langs**: All other technologies or languages that the interviewee may handle to succeed on the situation.
- **resolution time**: Expected resolution time for the situation. It can be a range.

# Example

## Describe what's wrong in this JS snippet

## Description

Please, read the code below and find the error.

## Payload

```javascript

let n, m = 50
let i, j = 0

while (i < n) {
  while (j < m) {
    consolelog(i, j)
    
    j += 1
  }
  
  i += 1
}
```

## Notes for the interviewer

### Evaluation method

Answer the question correctly.

### Positive response

- `let n, m = 50` is incorrect. `m` will be initialized to `50` but `n` will not.
- Same for `let i, j = 0`.
- `consolelog` is missing the dot between `console` and `log`.

### Extra points if

- They mention changing `j += 1` to `j++`.
- In general, nested loops are a code smell. Extra points if they mention it.
- Extra points if they mention declaring `n` and `m` with `const`, as they don't change in this scope.
- Extra points if they mention declaring each variable on its own line. It's a best practice meant to avoid this specific error when using initialization.

## Situation metadata

- Level: 0
- Preferred technology / language: Javascript
- Other supported technologies / languages: Any.
- Expected resolution time: 10 minutes.
