# Refactor the code below to TypeScript

## Description

Read the code below and explain what it does.

## Payload

```javascript
import db from './sql-db'

async function createUser (firstName, lastName) {
  const result = db.query(`
    INSERT INTO "user" ("fullName") VALUES ('${firstName} ${lastName}')
      RETURNING * ;
  `)

  return result.id
}
```

## Notes for the interviewer

- This exercise can be used to interview levels 1 to 4.

### Evaluation method

Read and explain the code.

### Positive response

- The code above takes 2 parameters and create a new user in the database using SQL code.

### Extra points if

- They mention that the `await` statement is missing. Level-2 indicator.
- They mention that there is no error handling. Level-2 indicator.
- They mention that we're losing data here (`firstName` and `lastName` are two different values and we're merging them when creating the user).
- They mention the problem with SQL injection. This is a level-3 response.
- They can answer this question correctly:
  - What would you change if there is a new requirement to support NoSQL databases alongside to SQL databases.
  - They should mention Dependency Inversion / Injection.
  - This is a level-4 question.

## Challenge metadata

- Level: 1-4
- Preferred technology / language: JavaScript / TypeScript / React
- Other supported technologies / languages: None.
- Expected resolution time:  minutes.
