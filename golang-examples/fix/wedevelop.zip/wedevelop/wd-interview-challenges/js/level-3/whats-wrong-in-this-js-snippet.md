# Describe what's wrong in this JS snippet

## Description

Please, read the code below and find the error.

## Payload

```javascript
let n, m = 50
let i, j = 0
while (i < n) {
  while (j < m) {
    consolelog(i, j)
    
    j += 1
  }
  
  i += 1
}
```

## Notes for the interviewer

### Evaluation method

Answer the question correctly.

### Positive response

- `let n, m = 50` is incorrect. `m` will be initialized to `50` but `n` will not.
- Same for `let i, j = 0`.
- `consolelog` is missing the dot between `console` and `log`.

### Extra points if

- They mention changing `j += 1` to `j++`.
- In general, nested loops are a code smell. Extra points if they mention it.
- Extra points if they mention declaring `n` and `m` with `const`, as they don't change in this scope.
This conversation was marked as resolved by abelosorio
- Extra points if they mention declaring each variable on its own line. It's a best practice meant to avoid this specific error when using initialization.

## Challenge metadata

- Level: 0
- Preferred technology / language: Javascript
- Other supported technologies / languages: Any.
- Expected resolution time: 10 minutes.
