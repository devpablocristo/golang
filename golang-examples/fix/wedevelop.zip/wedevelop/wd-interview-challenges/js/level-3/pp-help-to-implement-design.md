# Pair Programming: Help developer implement a design

## Description

Take a look at the screenshot below and the HTML code and write de CSS (TODO) code to implement this design.

## Payload

```html
TODO
```

## Notes for the interviewer

### Evaluation method

TODO

### Positive response

### Extra points if

## Challenge metadata

- Level:
- Preferred technology / language:
- Other supported technologies / languages:
- Expected resolution time:
