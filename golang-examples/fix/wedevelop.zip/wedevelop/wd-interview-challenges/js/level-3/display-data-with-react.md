# Display data with React (using Hooks)

## Description

Implement a small React component and use the Hook described below to display the User's full name in the application.

Note: Create this component in a separate isolated file. Do NOT create a completely new React App.

## Payload

```typescript
interface User {
  id
  firstName
  lastName
}

interface CurrentUserResult {
  currentUser?: User
  loading: boolean
  error?: Error
}

function useCurrentUser (): CurrentUserResult
```

## Notes for the interviewer

### Evaluation method

Code evaluation and refactoring.

### Positive response

- They handle `error` and `loading` states correctly.
- The code for the solution should look similar to:

```typescript
function MyComponent () {
  const { currentUser, loading, error } = useCurrentUser()

  // Extra points if they implement this (handling errors).
  if (error) {
    return (
      <>
        Oops! An error occurred while loading the current user information!
      </>
    )
  }

  // Extra points if they implement this (handling the loading state).
  if (loading) {
    return <>Loading...</>
  }

  return (
    <>
      <b>Full name:</b> {`${currentUser?.firstName} ${currentUser?.lastName}`}
    </>
  )
}
```

### Extra points if

- They use the `?.` notation (optional chaining operator).
- The error message is descriptive and clear to the end user.

## Challenge metadata

- Level: 3
- Preferred technology / language: JavaScript / TypeScript / React
- Other supported technologies / languages: None.
- Expected resolution time:  minutes.
