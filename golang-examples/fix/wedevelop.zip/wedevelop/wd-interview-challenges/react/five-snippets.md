# Five Snippets

Welcome to the WeDevelop Challenge! 🚀

## Description

- Complete the next five challenges.
- For solving it, you can use your local development environment or Codepen.

### Challenge 1: Show/Hide An Element

Make the button functional.

A click on button should toggle (show/hide) the string `Toggle Challenge` each time it is pressed.

- **`Work only on the JS source code.`**
- Solve the challenge here: <https://codepen.io/devpablocristo/pen/abLrKvK>

### Challenge 2: Counter App

Fix the counter app:

1. Pressing `+ 1` button should increase the counter count by one.
2. Pressing `- 1` button should decrease the counter count by one.
3. Pressing `Reset` button should reset to counter to zero.

- **`Work only on the JS source code.`**
- Codepen: <https://codepen.io/devpablocristo/pen/bGYGvwV>

### Challenge 3: Fetch Data from API

Given a url, fetch the data and display it (small hint: use `React.useEffect and fetch api`)

- **`Work only on the JS source code.`**
- Codepen: <https://codepen.io/devpablocristo/pen/zYEQJEZ>

### Challenge 4: ToDo App

Fix the ToDo app.

- **`Work only on the JS source code.`**
- Example: <https://imgur.com/a/rhJntQo>
- Codepen: <https://codepen.io/devpablocristo/pen/wvrbEOv>

### Challenge 5: Add tags

This app transform text into a tag.

1. You need to complete the app.

- **`Work only on the JS source code.`**
- Example: <https://imgur.com/a/MvqyfWz>
- Codepen: <https://codepen.io/devpablocristo/pen/PoOGKMV>

**Happy coding!**

## Notes for the interviewer

Sources:

- Challenge 1: <https://codepen.io/devpablocristo/pen/oNoWOGO>
- Challenge 2: <https://codepen.io/collinsworth/pen/eXxRZb>
- Challenge 3: <https://codepen.io/angelo_jin/pen/zYEWZdW>
- Challenge 4: <https://codepen.io/jfloresh631/pen/yLoRpyM>
- Challenge 5: <https://codepen.io/prvnbist/pen/jJzROe>

### Evaluation method

### Positive response

**3 - SSR:** 1, 2 and 3 correct.
**4 - SSR Upper:** 1, 2, 3 and 4 correct:
**5 - SR:** Challenge completed.

### Extra points if

- Pattern.
- Antipatterns.
- Architecture.
- Testing.
- Development philosophies.

## Challenge metadata

- Level: 3-4-5
- Preferred technology / language: Javascript
- Other supported technologies / languages: Any.
- Expected resolution time: 10 minutes.
