# Extra

- Create a login form, it must validate:
  - User: admin
  - Password: 12345
- Add a profile section where the user can add information:
  - Email.
  - Picture: Upload a picture from your computer.
- Add a button for dark/light mode switching functionality.
- Use I18n for internationalization.
