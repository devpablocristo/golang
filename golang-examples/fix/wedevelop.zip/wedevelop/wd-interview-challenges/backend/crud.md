# Create a web API

## Description

- Create a RESTful service that supports create, read, update, delete (CRUD) operations.
- Use your local development environment.

1. Create operations create and read.
2. Create operations update and delete.
3. Create an in-memory database for persisting products.
4. Test web API action methods with Postman (or a similar tool).
5. `(Extra point)`: Create a unit test.

**Happy coding!*

## Payload

## Notes for the interviewer

### Evaluation method

### Positive response

**3 - SSR:** At least 2 working operations.
**4 - SSR Upper:** The candidate created 4 working operations.
**5 - SR:** The candidate created 4 working operations and 1 unit test.
### Extra points if

- Pattern.
- Antipatterns.
- Architecture.
- Testing.
- Development philosophies.

## Challenge metadata

- Level: 3-4-5
- Preferred technology / language: Backend.
- Other supported technologies / languages: Any.
- Expected resolution time: 30 minutes.
