# Bookstore Inventory

Welcome to the WeDevelop Challenge! 🚀

## Description

- Create a RESTful API app for a bookstore's inventory.
- Use your local development environment.
- Databases are NOT required (except by the `(Extra point)`).

### Inventory Details

1. Inventory’s structure.
   1. Book’s title.
   2. Book’s stock (number of book copies in inventory of this specific book).
2. Book titles are unique:
   1. If n books have the same title, you must consider them as the same book.
   2. If n books have different titles, you must consider them as different books.

### Tasks

1. Add n copies of n books.
   1. Example:

    ```json
    [
        {
            "title": "Fundation",
            "stock": 10
        },
        {
            "title": "The Lord of the Rings",
            "stock": 50
        },
        {
            "title": "1984",
            "stock": 20
        },
        {
            "title": "1984",
            "stock": 100
        }
    ]
    ```

2. Delete n copies of n books.
   1. Example:

    ```json
    [
        {
            "title": "Fundation",
            "stock": 5
        },
        {
            "title": "The Lord of the Rings",
            "stock": 10
        }
    ]
    ```

3. List all books.
4. `(Extra point)`: Create a unit test.
5. `(Extra point)`: Use a SQL or a NoSQL DB for data persistence.

**Happy coding!**

## Notes for the interviewer

### Evaluation method

**3 - SSR:** 1, 2 and 3 correct.
**4 - SSR Upper:** 1, 2, 3 and 4 correct:
**5 - SR:** Challenge completed.

### Positive response

### Extra points if

## Challenge metadata

- Level: 3-4-5
- Technology area: Backend
- Expected resolution time: 30 minutes.
