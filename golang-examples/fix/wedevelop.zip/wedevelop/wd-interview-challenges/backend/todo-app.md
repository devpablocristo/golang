# Todo List App

Welcome to the WeDevelop Challenge! 🚀

## Description

- Create a RESTful API todo list app.
- Databases are NOT required (except by the `(Extra point)`).
- Use your local development environment.
- Frontend development is NOT required, only backend.
  - The designs are shown only to help you to undertand the challenge.
  - Desings: <https://imgur.com/a/YzvWg7s>

### Tasks

1. Add a new task.
2. Mark a task as completed.
3. Toggle between All, Active and Completed.
4. Remove one or all tasks under the Completed tab.
5. `(Extra point)`: Create a unit test.
6. `(Extra point)`: Use a SQL or a NoSQL DB for data persistence.

**Happy coding!**

## Notes for the interviewer

Sources:

1. <https://devchallenges.io/challenges/hH6PbOHBdPm6otzw2De5>

### Evaluation method

**3 - SSR:** 1, 2 and 3 correct.
**4 - SSR Upper:** 1, 2, 3 and 4 correct:
**5 - SR:** Challenge completed.

### Positive response

### Extra points if

- Pattern.
- Antipatterns.
- Architecture.
- Testing.
- Development philosophies.

## Challenge metadata

- Level: 3-4-5
- Preferred technology / language: Backend.
- Other supported technologies / languages: Any.
- Expected resolution time: 30 minutes.
