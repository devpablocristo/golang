# Magento Challenge 1

Welcome to the WeDevelop Challenge! 🚀

## Description

### Challenge 1

Please answer the next questions:

1. What are the problems with the following code in a .phtml file:

    ```php
    <?php
    $products = Mage::getModel('catalog_products')
    ->getCollection()
    ->addFieldToFilter('price' ['>' => 100]);
    ?>
    <h1>Our products less than $100:</h1>
    <ul>
    <?php
    foreach ($products as $product) {
            echo '<li>' . $product->getName() . '</li>';
    }
    ?>
    </ul>
    ```

2. When catalog_product_flat_data is running, what are the consequences for the store?
3. In Magento 2, what are the different deploy modes and what are their differences?
4. In Magento 2, what is dependency injection and what are its advantages?
5. What is the best way to count the items in a collection? Explain the differences with other method(s).
6. What does EAV mean? What are the advantages and disadvantages of it, and how does Magento addresses the issues associated with it?
7. In Magento 2, what is a factory class and how does it work?
8. What is the difference between a store and a website? (hint: parameters)

### Challenge 2

To complete the module, you will have to create the following files:

- A few boilerplate registration files, to make Magento aware of your Blog module.
- One interface file, to define the data contract for the Post.
- A Post Model, to represent a Post throughout your code, implementing the Post data interface.
- A Post Resyource Model, to link the Post Model to the database.
- A Post Collection, to retrieve several posts at once from the database with the help of the Resyource Model.
- Two migration classes, to set up your table schema and content.
- Two Actions: one to list all posts and another to show each post individually.
- Two each of Blocks, Views, and Layout files: One of each for the list action, and one of each for the view.

**Happy coding!**

## Payload

## Notes for the interviewer

Sources:

- <https://www.toptal.com/magento/magento-2-tutorial-building-a-complete-module>
- <https://www.toptal.com/magento/interview-questions>

### Evaluation method

### Positive response

#### Challenge 1

1. Ans:

   Loading a model in a template file is bad practice. The template should be for representational logic only. Respect the MVC architecture.

    The title should be translated:

    ```php
    <h1><?php echo $this->__('Our products less than $100') ?> :</h1>
    ```

    The attribute “name” is not selected:

    ```php
    ->addAttributeToSelect('name')
    ```

    The correct model name is catalog/product and not catalog_products.

    The correct expression for addFieldToFilter is :

    ```php
    ->addFieldToFilter('price', ['lt' => 100]);
    ```

    Here is a corrected version:

    Block class:

    ```php
    Class Toptal_Test_Block_Demo extends Mage_Catalog_Block_Product_Abstract {
        public function getProductsLessThan($price){
            return Mage::getModel('catalog/product')
                    ->getCollection()
                    ->addAttributeToSelect('name')
                    ->addFieldToFilter('price', ['lt' => $price]);
        }
    }
    ```

    Template file:

    ```php
        <?php $price = 100 ?>
            <h1><?php echo $this->__('Our products less than %s', Mage::helper('core')->currency($price , true, false)) ?> :</h1>
            <ul>
            <?php
            /** @var Mage_Catalog_Model_Product $product */
            foreach ($this->getProductsLessThan($price) as $product) {
                echo '<li>' . $product->getName() . '</li>';
            }
        ?>
    </ul>
    
    ```

    There are other issues related to visibility, output formatting, base currency, etc. that you should also be careful about.

2. Ans:

   When flat catalog indexing is running, the data is retrieved through EAV. Therefore performance is slowed down by both the indexing process and overhead due to EAV retrieval. The information from the products is still correct.

3. Ans:

    **Developer**

    In this mode, all the files in pub/static/ are symlinks to the original file. Exceptions are thrown and errors are displayed in the front end. This mode makes pages load very slowly, but makes it easier to debug, as it compiles and loads static files every time. Cache can still be enabled.

    **Default**

    This default is enabled out-of-the-box. It is a state in between production and developer, as the files are generated when they are needed. I.e. CSS files are generated using several LESS files in several locations. These files will be generated only when they are needed by the front end, and will not be generated again the next time they are needed.

    **Production**

    This mode should be enabled for all Magento 2 websites in production, as all the required files are generated and placed in the pub/static folder

4. Ans:

    Dependency injection is a design pattern strategy that relegates the responsibility of injecting the right dependency to the calling module or framework. This is the Hollywood Principle: “Don’t call us, we’ll call you.”

    The responsibility of calling the right dependency is no longer handled by the function and respects the SOLID principle.

    Its main advantages are that it makes code:

    - Easier to test
    - Easier to re-use
    - Easier to maintain

5. Ans:

    The best way is to use the method getSize(). This function will not load the collection each time to count the items but store it. So every time you need this value you will not have to recalculate it. Moreover, it uses the SQL COUNT() function in order to speed up the counting process. However, if the collection has been modified, this value can become inconsistent.

    In contrast, the count() method will load the collection and count its items every time it is called. This can become very resource demanding.

6. Ans:

    EAV stands for entity-attribute-value. It is the way customers, products, and address data are stored in Magento’s database. In order to retrieve information about a customer (entity), you will need to query three tables. For example, if you need to get the date of birth (attribute) of a customer (entity), you will need to retrieve the customer ID using its email address by querying the customer_entity table, the dob attribute ID in the eav_attribute table, and finally use both the entity ID and attribute ID in order to retrieve the date (value) in the customer_entity_datetime table.

    While this makes it complicated to retrieve a value and requires multiple calls, it makes the system very flexible and allows the user to change the attributes, adding and removing them easily without having to modify the database schema.

    In order to make data retrieval faster, Magento uses flat tables that are regenerated using indexes; it allows you to retrieve some values querying only this table.

    The efficiency and usability of this model is debatable and is still a subject of great discussion between pro- and anti-EAV camps.

7. Ans:

    Factory classes are generated when code generation happens. They are created automatically for models that represent database entities.

    Factory classes are used to create, get, or change entity records without using the ObjectManager directly, as its direct usage is discouraged by Magento. (This is because it goes against the principles of dependency injection.)

    These classes do not need to be manually defined, but they can be, in case you need to define a specific behavior.

8. Ans:

   Some parameters are defined by a store and some are defined by a website:

    Parameter / Scope
    Product settings / Default, Store View
    Product prices / Default, Website
    Product tax class / Default, Website
    Base currency / Default, Website
    Display currency / Default, Store view
    System configuration settings / Default, Website, and Store view
    Root category configuration / Store group
    Orders / Store view
    Customers / Default, Website
    Category settings / Default, Store view
    For example, if you need to define different base currencies, you will need two different websites.

Magento’s architecture

Magento’s architecture was designed with the intent of making the syource code as modularized and extensible as possible. The end goal of that approach is to allow it to be easily adapted and customized according to each project’s needs.

Magento 2 is a Model View ViewModel (MVVM) system. While being closely related to its sibling Model View Controller (MVC), an MVVM architecture provides a more robust separation between the Model and the View layers.

- The Model holds the business logic of the application, and depends on an associated class—the ResyourceModel—for database access. Models rely on service contracts to expose their functionality to the other layers of the application.
- The View is the structure and layout of what a user sees on a screen - the actual HTML. This is achieved in the PHTML files distributed with modules. PHTML files are associated to each ViewModel in the Layout XML files, which would be referred to as binders in the MVVM dialect. The layout files might also assign JavaScript files to be used in the final page.
- The ViewModel interacts with the Model layer, exposing only the necessary information to the View layer. In Magento 2, this is handled by the module’s Block classes. Note that this was usually part of the Controller role of an MVC system. On MVVM, the controller is only responsible for handling the user flow, meaning that it receives requests and either tells the system to render a view or to redirect the user to another route.
- A Magento 2 module consists of some, if not all, elements of the architecture described above. The overall architecture is described below (syource)

Each modules folder holds one part of the architecture, as follows:

- Api: Service contracts, defining service interfaces and data interfaces
- Block: The ViewModels of your MVVM architecture
- Controller: Controllers, responsible for handling the user’s flow while interacting with the system
- etc: Configuration XML files—The module defines itself and its parts (routes, models, blocks, observers, and cron jobs) within this folder. The etc files can also be used by non-core modules to override the functionality of core modules.
- Helper: Helper classes that hold code used in more than one application layer. For example, in the Cms module, helper classes are responsible for preparing HTML for presentation to the browser.
- i18n: Holds internationalization CSV files, used for translation
- Model: For Models and ResyourceModels
- Observer: Holds Observers, or Models which are “observing” system events. Usually, when such an event is fired, the observer instantiates a Model to handle the necessary business logic for such an event.
- Setup: Migration classes, responsible for schema and data creation
- Test: Unit tests
- Ui: UI elements such as grids and forms used in the admin application
- view: Layout (XML) files and template (PHTML) files for the front-end and admin application.

### Extra points if

## Challenge metadata

- Level: 3-4-5
- Preferred technology / language: Javascript
- Other supported technologies / languages: Any.
- Expected resolution time: 10 minutes.
