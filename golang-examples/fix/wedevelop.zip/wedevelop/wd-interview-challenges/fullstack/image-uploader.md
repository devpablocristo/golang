# Image Uploader

## Description

Create an Image Uploader application.

- Use any frontend libraries of your choice.
- Create your API.
- Fulfill user stories below.

### Stories

1. User story: I can drag and drop an image to upload it
2. User story: I can choose to select an image from my folder
3. User story: I can see a loader when uploading
4. User story: When the image is uploaded, I can see the image and copy it
5. User story: I can choose to copy to the clipboard

- Icon: <https://google.github.io/material-design-icons/>
- Example: <https://imgur.com/a/S9UuinV>
- Styles and images: <https://github.com/devpablocristo/wd-fullstack-image-uploader>

**Happy coding!**

## Notes for the interviewer

Sources:

1. <https://devchallenges.io/challenges/O2iGT9yBd6xZBrOcVirx>

### Evaluation method

### Positive response

### Extra points if

## Challenge metadata

- Level: 3-4-5
- Preferred technology / language: Any
- Other supported technologies / languages: Any.
- Expected resolution time: 10 minutes.
