# Golang Challenge

Welcome to the WeDevelop Challenge! 🚀

## Description

- Please solve the next three challenges.
- Use your local development environment.
- Databases are NOT required.

### Challenge 1

Please answer the next questions.

1. Is Go a case sensitive language?
    - A. Yes.
    - B. No.
    - C. Sometimes.
    - D. Both.

2. What is the usage of the break statement in Go?
    - A. Terminate the for loop or switch statement.
    - B. Terminate the if/else statement.
    - C. Terminate a recursive function.
    - D. Escape an interface.

3. What is a map in Go?
    - A. Is a store for location data.
    - B. Is a variable that is used to store the memory address of another variable.
    - C. Is a key-value store.
    - D. Is a type for concurrent programming.

4. Can you return multiple values from a function?
    - A. Only if one of the values is an error.
    - B. Yes.
    - C. No.
    - D. This is only valid for methods, not functions.

5. What are structs in Go? What are they used for?
    - A Is ORM data type. It allows us to interact with a database engine.
    - B.Is a behavior driven type. It allows us to describe desired behavior.
    - C. Is a goroutine group. It allows us to execute functions independently and simultaneously.  
    - D. Is a composite data type. It allows us to compose together values of different types.

6. Does Go support type encapsulation?
    - A. Yes, only on public and protected methods.
    - B. No, Go is not an object oriented programming language.
    - C.  Yes, using the capitalized and non-capitalized formats.
    - D. No, Go works only with packages.

7. What's the difference between functions and methods in Go?
    - A. There is no difference.
    - B. A method is nothing more than a function attached to a type.
    - C. A method is a function that belongs to a package.
    - D. Functions can return multiple values, methods only one.

8. What are interfaces in Go?
    - A. Interfaces are a special type in Go that define a set of method signatures but do not provide implementations.
    - B. Interfaces are a special type in Go that define a set of method signatures and  implementations.
    - C. Interfaces are a special type in Go that define a set of functions but do not provide implementations.
    - D. Interfaces are a special type in Go that define a set of functions and implementations.

9. What are empty interfaces in Go?
    - A. Are an abstraction of the interface type. Can hold values of any type.
    - B. Are interfaces that specify zero variables, functions and structs. Can be accessed from anywhere.
    - C. Are interfaces that specify zero methods. Can hold values of any type.
    - D. Are interfaces that are empty of error handling. Can be used to test errors.

10. What is Context? What is Golang context used for?
    - A. Package context defines the Context type, which carries deadlines, cancellation signals, and other request-scoped values across API boundaries and between processes.
    - B. Context is a special structure, which carries deadlines, cancellation signals, and other request-scoped values across API boundaries and between processes.
    - C. A variable that holds the Context of an interface, such as methods, values and errors.
    - D. A variable that defines the scope of a type.

### Challenge 2

- This is an app for a bookstore.
- Fix and finish the app.
- Use your local development environment.
- Notes:
  - The isbn it's unique for each book.
    - Each book, not each copy of a book.
  - Use this `json array` for adding more books:
  
    ```json
    [
        {
            "book": {
                "author": {
                    "firstname": "Frank",
                    "lastname": "Herbert"
                },
                "title": "Dune",
                "price": 53.79,
                "isbn": "0340960191"
            },
            "stock": 5
        },
        {
            "book": {
                "author": {
                    "firstname": "Isaac",
                    "lastname": "Asimov"
                },
                "title": "Fundation",
                "price": 28.5,
                "isbn": "0-553-29335-4"
            },
            "stock": 1
        }
    ]
    ```

### Payload Challenge 2

```go
package main

import (
    "encoding/json"
    "fmt"
    "io/ioutil"
    "log"
    "net/http"

    "github.com/gorilla/mux"
)

type InventoryInfo struct {
    Title string `json:"title"`
    Stock int64  `json:"stock"`
}

var Inventory []InventoryInfo

func main() {

    book1 := Book{
        Author: Person{
        Firstname: "Isaac",
        Lastname:  "Asimov",
        },
        Title: "Fundation",
        Price: 28.50,
        ISBN:  "0-553-29335-4",
    }

    book2 := Book{
        Author: Person{
        Firstname: "Stanislaw",
        Lastname:  "Lem",
        },
        Title: "Solaris",
        Price: 65.20,
        ISBN:  "0156027607",
    }

    book3 := Book{
        Author: Person{
        Firstname: "Arthur C.",
        Lastname:  "Clarck",
        },
        Title: "Rendezvous with Rama",
        Price: 53.50,
        ISBN:  "0-575-01587-X",
    }

    book4 := Book{
        Author: Person{
        Firstname: "William",
        Lastname:  "Gibson",
        },
        Title: "Neuromancer",
        Price: 42.75,
        ISBN:  "0-441-56956-0",
    }

    Inventory = []InventoryInfo{
        InventoryInfo{
            Book:  book1,
            Stock: 1,
        },
        InventoryInfo{
            Book:  book2,
            Stock: 2,
        },
        InventoryInfo{
            Book:  book3,
            Stock: 3,
        },
        InventoryInfo{
            Book:  book4,
            Stock: 4,
        },
    }

    router := mux.NewRouter()

    const port string = ":8000"

    router.HandleFunc("/inventory", listBooks).Methods("GET")
    router.HandleFunc("/inventory", addBooks).Methods("POST")

    log.Println("Server listining on port", port)
    log.Fatalln(http.ListenAndServe(port, router))
}

```

### Challenge 3

- Run and explain what is happening in this program.

### Payload Challenge 3

```go
package main

import (
 "fmt"
 "sync"
)

func main() {

 gs := 100

 var wg sync.WaitGroup
 wg.Add(gs)

 incrementer := 0
 for i := 0; i < gs; i++ {

  go func() {
   v := incrementer
   fmt.Println(incrementer)
   v++
   incrementer = v
   fmt.Println(incrementer)
   wg.Done()
  }()
 }
 wg.Wait()
 fmt.Println(incrementer)

}
```

**Happy coding!**

## Notes for the interviewer

### Evaluation method

### Positive response

#### Answer Challenge 1

1. Is Go a case sensitive language?
    - Ans: A. Yes.

2. What is the usage of the break statement in Go?
    - Ans: A. The break statement is used to terminate the for loop or switch statement.
    It transfers execution to the statement immediately following the for loop or switch.

3. What is a map in Go?
    - Ans: C. A map is a key-value store.
    This means that you store some value and you access that value by a key.
    Ask for an example:

    ```go
    m := map[string]int{
        "Juan":32,
        "Sofia": 27,    
    }
    fmt.Println(m) // output: map[Juan:32 Sofia:27]
    fmt.Println(m["Juan"]) // output: 32
    ```

4. Can you return multiple values from a function?
    - Ans: B. Yes
    Ask for an example:

    ```go
    func swap(x, y string) (string, string) {
    return “foo”, “var”
    }
    ```

5. What are structs in Go? What are they used for?
    - Ans: D- Is a composite data type. It allows us to compose together values of different types.
    Ask for an example:

    ```go
    type person struct {
        first string
        last  string
        age   int
    }

    func main() {
        p1 := person{
            first: "Thomas",
            last:  "Anderson",
            age:   32,
        }
    }
    ```

6. Does Go support type encapsulation?
    - Ans: C. Yes, using the capitalized and non-capitalized formats.
    Go doesn’t have any public, private or protected keyword. The only mechanism to control the visibility is using the capitalized and non-capitalized formats.
        - Capitalized Identifiers are exported: The capital letter indicates that this is an exported identifier.
        - Non-capitalized identifiers are not exported: The lowercase indicates that the identifier is not exported and will only be accessed from within the same package.

7. What's the difference between functions and methods in Go?
    - Ans: B. A method is nothing more than a function attached to a type.
    When you attach a func to a type it is a method of that type.
    You attach a func to a type with a RECEIVER.
    In method declaration syntax, a "receiver" is used to represent the container of the function.
    This receiver can be used to call functions using "." operator.
    Ask for an example:

    ```go
    // function
    func MyFunction(a, b int) int {
        return a + b
    }
    // usage:
    // MyFunction(1, 2)

    // method
    type MyInteger int
    func (a MyInteger) MyMethod(b int) int {
        return a + b
    }
    // usage:
    // var x MyInteger = 1
    // x.MyMethod(2)
    ```

8. What are interfaces in Go?
    - Ans: A. Interfaces are a special type in Go that define a set of method signatures but do not provide implementations.
    Ask for an example:

    ```go
    //interface
    type geometry interface {
        area() float64
        perim() float64
    }

    type rect struct {
        width, height float64
    }
    type circle struct {
        radius float64
    }

    func (r rect) area() float64 {
        return r.width * r.height
    }
    func (r rect) perim() float64 {
        return 2*r.width + 2*r.height
    }

    func (c circle) area() float64 {
        return math.Pi * c.radius * c.radius
    }
    func (c circle) perim() float64 {
        return 2 * math.Pi * c.radius
    }

    func measure(g geometry) {
        fmt.Println(g)
        fmt.Println(g.area())
        fmt.Println(g.perim())
    }

    func main() {
        r := rect{width: 3, height: 4}
        c := circle{radius: 5}

        measure(r)
        measure(c)
    }
    ```

9. What are empty interfaces in go?
    - Ans: C. Are interfaces that specify zero methods. Can hold values of any type.

10. What is Context? What is Golang context used for?
    - Answer: A. The package context defines the Context type, which carries deadlines, cancellation signals, and other request-scoped values across API boundaries and between processes.

#### Answer Challenge 2

the candidate shoud alt le

#### Answer Challenge 3

- Race condition.

### Extra points if



## Challenge metadata

- Level: 3-4-5
- Preferred technology / language: Golang
- Other supported technologies / language: None.
- Expected resolution time: 30 minutes.
