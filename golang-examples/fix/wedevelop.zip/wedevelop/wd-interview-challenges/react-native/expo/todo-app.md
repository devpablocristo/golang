# Todo List App

Welcome to the WeDevelop Challenge! 🚀

## Description

- Create a todo list app.
- Databases are NOT required.
- Use you own development environment or Expo.

### Tasks

1. Add a new task.
2. Mark a task as completed.
3. Toggle between All, Active and Completed.
4. Remove one or all tasks under the Completed tab.
5. Apply styles, follow the given designs.
6. `(Extra point)`: Create a unit test.
7. `(Extra point)`: Store the data in local storage that when I refresh the page I can still see my progress.

Icon: <https://google.github.io/material-design-icons/>
Desings: <https://imgur.com/a/YzvWg7s>
Expo: <https://snack.expo.dev/@devpablocristo/wd-react-native-challenge>

**Happy coding!**

## Notes for the interviewer

Sources:

1. <https://devchallenges.io/challenges/hH6PbOHBdPm6otzw2De5>

### Evaluation method

**3 - SSR:** Puntos 1,2,3, 4 correctos.
**4 - SSR Upper:** Puntos 1,2,3, 4 y 5 correctos.
**5 - SSR Upper:** Todos los puntos correctos.

### Positive response

### Extra points if

## Challenge metadata

- Level: 0
- Preferred technology / language: Javascript
- Other supported technologies / languages: Any.
- Expected resolution time: 10 minutes.

esta es para otra todo app, no para esta
//<https://imgur.com/a/QjnhXdg>
