# Get and display the API elements

Welcome to the WeDevelop Challenge! 🚀

## Description

- Create an app for a bookstore.
- Databases are NOT required.
- Use you own development environment or Expo.

### Tasks

1. Display the API elements:
   1. Book title.
   2. Book price.
   3. Book image.
2. Add button to mark a book as favorite.
3. Apply styles, follow the given designs.
4. `(Extra point)`: Add button to list all favorites. Save favorites with redux or context API.
5. `(Extra point)`: Create a unit test.

API: <https://api.itbook.store/1.0/new>
Designs: <https://imgur.com/a/UgnKlXb>
Expo: <https://snack.expo.dev/@devpablocristo/wd-react-native-challenge>

**Happy coding!**

---

## Notes for the interviewer

### Evaluation method

### Positive response

### Extra points if

## Challenge metadata

- Level: 3-4-5
- Preferred technology / language: React Native
- Other supported technologies / languages: None.
- Expected resolution time: 10 minutes.
