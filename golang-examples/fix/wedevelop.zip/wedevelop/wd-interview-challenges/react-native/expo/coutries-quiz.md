# Countries Quiz

Welcome to the WeDevelop Challenge! 🚀

## Description

- Create an app for a bookstore.
- Databases are NOT required.
- Use you own development environment or Expo.

### Tasks

- Display at least 2 types of questions:
  - a city is the capital of...
  - or a flag belong to country...
- Display an answer selector.
- Display if the answer is correct or incorrect.
  - If the answer is correct, can move on to the next question.
  - If the answer is incorrect, show results and  the "try again" button .
- The "try again" starts a new game.
- `(Extra point)`: Create a unit test.

API: <https://restcountries.eu/>. Use data from the API to create questions and answers.
Designs: <https://imgur.com/a/eYcuMH5>
Expo: <https://snack.expo.dev/@devpablocristo/wd-react-native-challenge>
Icon: <https://google.github.io/material-design-icons/>

**Happy coding!**

---

## Notes for the interviewer

Sources:

1. <https://devchallenges.io/challenges/Bu3G2irnaXmfwQ8sZkw8>

### Evaluation method

### Positive response

### Extra points if

## Challenge metadata

- Level: 3-4-5
- Preferred technology / language: React Native
- Other supported technologies / languages: None.
- Expected resolution time: 10 minutes.
