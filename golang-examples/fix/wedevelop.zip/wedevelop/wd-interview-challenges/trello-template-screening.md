# Technical Interview

## LANGUAGES

C()
C++()

C#()
C#/.NET()

Java{BE}()
Java/Spring()
Java/Struts()
Java/Hibernate()

Kotlin{BE}()

Golang()
Gin/Golang()

Pearl()

Ruby()
Ruby/RoR()

PHP()
PHP/Laravel()
PHP/Symfony()

Python{BE}()
Python/Flask()
Python/Django()
Python/FastAPI()

JS()
Typescript()

Node.js()
Node.js/Express()
Node.js/Nest()

React()
React/Next()
React/Gatsby()

Angular()
Vue()

React Native()

Swift{iOS}()
Objective-C{iOS}()

Java{Android}()

Flutter{Android}()
Kotlin{Android}()

Python{Data Science}()

## QUALITY ASSURANCE

Manual()

Cypress()

Selenium/Node.js()
Selenium/Python()
Selenium/Ruby()
Selenium/Java()
Selenium/Kotlin()
Selenium/C#()

## DEVOPS/INFRA

Docker
Kubernetes
Swarm
CI/CD
Pipelines
Jenkins
Linux/Unix
Infra as a code
Ansible
Terraform
Carnates
Helm
Git
GitHub (or another repos)

## DATABASES

MySQL()
SQLite()
Oracle()
Postgres()
Microsfot SQL Server()
MongoDB()
DynamoDB()
CosmosDB()
Firebase()
Cassandra()
Elasticsearch()
Redis()

## AVAILABILITY

---

## TECH RESULTS

English: | BE: | FE: | QA man: | QA auto: | MO: | DevOps: |

---

## NOTES

---