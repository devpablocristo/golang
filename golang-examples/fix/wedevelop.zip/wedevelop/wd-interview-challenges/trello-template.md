# Technical Interview

## LANGUAGES

C()
C++()

C#()
C#/.NET()

Java{BE}()
Java/Spring()
Java/Struts()
Java/Hibernate()

Kotlin{BE}()

Golang()
Gin/Golang()

Pearl()

Ruby()
Ruby/RoR()

PHP()
PHP/Laravel()
PHP/Symfony()

Python{BE}()
Python/Flask()
Python/Django()
Python/FastAPI()

JS()
Typescript()

Node.js()
Node.js/Express()
Node.js/Nest()

React()
React/Next.js()
React/Gatsby()

Angular()
Vue()

React Native()

Swift{iOS}()
Objective-C{iOS}()

Java{Android}()

Flutter{Android}()
Kotlin{Android}()

Python{Data Science}()

## QUALITY ASSURANCE

Manual()

Cypress()

Selenium/Node.js()
Selenium/Python()
Selenium/Ruby()
Selenium/Java()
Selenium/Kotlin()
Selenium/C#()

## DEVOPS/INFRA

Docker
Kubernetes
Swarm
CI/CD
Pipelines
Jenkins
Linux/Unix
Infra as a code
Ansible
Terraform
Carnates
Helm
Git
GitHub (or another repos)

## DATABASES

MySQL()
SQLite()
Oracle()
Postgres()
Microsfot SQL Server()
MongoDB()
DynamoDB()
CosmosDB()
Firebase()
Cassandra()
Elasticsearch()
Redis()

## AVAILABILITY

---

## TECH RESULTS

English: | BE: | FE: | QA man: | QA auto: | MO: | DevOps: |

---

## CHALLENGES

---

## DETAILS

## 1. English

- Speaking:
- Understanding:
- Fluency:
- Accent:
- Extra:
- Total:

  - AAA

## 2. Tech

SUMMARY

- AAA

CHALLENGES RESULTS

- AAA

TESTING TOOLS

- Mockito
- Juniper
- Jest
- Junit
- TestNG
- Testify
- Testcontainers
- Nock (endpoints mock)
- Mocka
- Datadog
- Gomock
- Cypress
- Selenium

ORMs

- GORM
- Active Record
- Sequelize
- Hibernate

INFRA

- Docker
- Kubernetes
- CI/CD
- GitHub (or another repos)
- Git Workflows
  - Git Feature Branch Workflow
  - Forking Workflow
  - Gitflow Workflow
- Cloud Services
  - AWS
  - GCP
  - Azure
  - Digital Ocean
  - Firebase

COMMUNICATION BETWEEN SERVICES

- REST
- GraphQL
- RabbitMQ
- Websockets
- gRPC
- SOAP
- Kafka

AUTHENTICATION

- JWT
- Oauth
- Auth0
- 2 Factor authentication
- Passport

AGILE METHODOLOGIES

- Scrum
- Kanban
- Jira
- Trello
- Planner

ARCHITECTURAL PATTERNS

- Hexagonal
- Clean
- Layered
- Microservices
- MVC

DESIGN PATTERNS

- Strategy
- Singleton
- Factory
- Facade

SOFTWARE DEVELOPMENT PHILOSOPHIES

- DDD
- TDD
- BDD

DEBUGGING METHODOLOGY

## 3. Soft

- AAA

## 4. Extra

- AAA

---

Aprobado (botón)

El candidato no se presentó.

ok aprobado= vicky

aprobado con ingles muy bueno = euge
