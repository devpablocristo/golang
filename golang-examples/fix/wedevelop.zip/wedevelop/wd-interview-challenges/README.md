# Interview Challenges

Real-life Challenges that we use to evaluate our people or recruitees.

## Metodo de evaluación

1. 15 minutos
   1. Introducción
   2. Experiencia e inglés.
2. 30 minutos
   1. Challenge live coding
3. 15 minutos
   1. Charla/defensa

De lo hecho el challenge más la charla, extrolar:

- 1. Jr.
- 2. Jr upper.
- 3. Ssr.
- 4. Ssr upper.
- 5. Sr.
