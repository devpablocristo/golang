# Rezise iframe

## Description

- Normally you set and width and height for iframes. If the content inside is bigger, scrollbars have to suffice. 
- You will fix that by dynamically resizing the iframe to fit the content it loads.

```html
<iframe src="content.html" class="iframe" scrolling="no" frameborder="0"></iframe>
```

**Happy coding!**

---

## Notes for the interviewer

### Evaluation method

De aqui saco los snippets:

<https://bootsnipp.com/>
<https://css-tricks.com/snippets/jquery/>

https://css-tricks.com/snippets/jquery/fit-iframe-to-content/

### Positive response

```js
<script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js?ver=1.3.2'></script>
<script type='text/javascript'>
    
    $(function(){
    
        var iFrames = $('iframe');
      
     function iResize() {
     
      for (var i = 0, j = iFrames.length; i < j; i++) {
        iFrames[i].style.height = iFrames[i].contentWindow.document.body.offsetHeight + 'px';}
         }
         
         if ($.browser.safari || $.browser.opera) { 
         
            iFrames.load(function(){
                setTimeout(iResize, 0);
               });
            
            for (var i = 0, j = iFrames.length; i < j; i++) {
           var iSource = iFrames[i].src;
           iFrames[i].src = '';
           iFrames[i].src = iSource;
               }
               
         } else {
            iFrames.load(function() { 
                this.style.height = this.contentWindow.document.body.offsetHeight + 'px';
            });
         }
        
        });

</script>
```


### Extra points if

## Challenge metadata

- Level: 3
- Preferred technology / language: Boostrap/JQuery.
- Other supported technologies / languages: None.
- Expected resolution time: 10 minutes.
