# Oracle Queries

Welcome to the WeDevelop Challenge! 🚀

## Description

- Use your local development environment.

Download database: <https://github.com/devpablocristo/wd-oracle-challenge>

1. Use a view to return sales amount by customer by year
2. The following statement gets the employee and order data of the salesman id 57.

**Happy coding!**

## Payload

## Notes for the interviewer

Sources:

1. <https://www.oracletutorial.com/oracle-view/>
2. <https://www.oracletutorial.com/oracle-basics/>

### Evaluation method

### Positive response

1. Solution:

    ```sql
    CREATE OR REPLACE VIEW customer_sales AS 
    SELECT
        name AS customer,
        SUM( quantity * unit_price ) sales_amount,
        EXTRACT(
            YEAR
        FROM
            order_date
        ) YEAR
    FROM
        orders
    INNER JOIN order_items
            USING(order_id)
    INNER JOIN customers
            USING(customer_id)
    WHERE
        status = 'Shipped'
    GROUP BY
        name,
        EXTRACT(
            YEAR
        FROM
            order_date
        );
    ```

    Now, you can easily retrieve the sales by the customer in 2017 with a more simple query:

    ```sql
    SELECT
        customer,
        sales_amount
    FROM
        customer_sales
    WHERE
        YEAR = 2017
    ORDER BY
        sales_amount DESC;
    ```

2. Solution:

   ```sql
   SELECT
       employee_id,
       last_name,
       first_name,
       order_id,
       status
   FROM
       orders
   RIGHT JOIN employees ON
       employee_id = salesman_id
   WHERE
       employee_id = 57;
   ```

### Extra points if

## Challenge metadata

- Level: 0
- Preferred technology / language: Orcle DB
- Other supported technologies / languages: SQL like.
- Expected resolution time: 10 minutes.
