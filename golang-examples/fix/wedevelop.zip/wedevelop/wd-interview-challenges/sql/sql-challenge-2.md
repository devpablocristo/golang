# SQL Challenge 2

Welcome to the WeDevelop Challenge! 🚀

## Description

- Use your local development environment.
- Use MySQL, Oracle, Microsoft SQL Server or Postgres for your solutions.
- Download the tables from the repo
  - Repo: <https://github.com/devpablocristo/wd-sql-challenge-2>

1. Create a stored procedure called `uspCountriesAsia` to:
   1. List out all the countries with ContinentId equal to 1.
   2. In alphabetical order.
   3. Show the CountryId of each country.
2. Create a query which lists out all of the events in the tblEvent table which happened after the last one for country 21 (International) took place.  
   Here's the gist of what you need to do:

      ```sql
      SELECT
         list of fields
      FROM
         table of events
      WHERE
         Event date > (
            SELECT MAX(Event date)
            FROM table of events
            WHERE country id = 21
         )
      ORDER BY
      Event date (descending)
      ```

3. Create a query which joins to the results of your table-valued function to show the category and country for each event in a given year.
   1. For example, you should be able to run this query:

      ```sql
      SELECT
      *
      FROM
      dbo.fnEventsForYear(1918) AS e
      ```

4. List the names of the companions who haven't featured in any episodes. You should find there's one of them.
   1. Create a query based on the companions table, with an outer join to the episode companion table.
5. Using the following tables tblEnemy, tblEpisodeEnemy and tblEpisode create a query to show all of the episodes which feature enemies containing the letters `Dalek`.
   1. This query should return 16 rows when you run it.
   2. Change this query into a stored procedure called `spEnemyEpisodes`, which lists out all of the episodes featuring a given enemy. Here are some results you should get when you try running this stored procedure with different parameters:

      Procedure ----- Number of rows returned
      spEnemyEpisodes 'ood' ----- 4 (the episodes featuring the Ood)
      spEnemyEpisodes 'auton' ----- 1 (episode featuring the Auton)
      spEnemyEpisodes 'silence' ----- 5 (episodes featuring the Silence)

**Happy coding!**

## Payload

## Notes for the interviewer

Sources:

1. <https://www.wiseowl.co.uk/sql/exercises/standard/stored-procedures/4267/>
2. <https://www.wiseowl.co.uk/sql/exercises/standard/subqueries/4132/>
3. <https://www.wiseowl.co.uk/sql/exercises/standard/table-valued-functions/4263/>
4. <https://www.wiseowl.co.uk/sql/exercises/standard/more-exotic-joins/4034/>
5. <https://www.wiseowl.co.uk/sql/exercises/standard/parameters-and-return-values/3971/>

### Evaluation method

### Positive response

1. Ans:
2. Ans:

   ```sql
   SELECT
      e.EventName,
      e.EventDate,
      c.CountryName
   FROM
      tblEvent AS e
      INNER JOIN tblCountry AS c
         ON e.CountryID = c.CountryID
   WHERE
      e.EventDate > (
         SELECT MAX(ev.EventDate)
         FROM tblEvent AS ev
         WHERE ev.CountryID = 21 
      )
   ORDER BY
      e.EventDate DESC

      --SELECT
      -- list of fields
      --FROM 
      -- table of events
      --WHERE
      -- Event date > (
      --  SELECT MAX(Event date)
      --  FROM table of events
      --  WHERE country id = 21
      -- )
      -- ORDER BY
      --  Event date (descending)
   ```

### Extra points if

## Challenge metadata

- Level: 3-4-5
- Preferred technology / language: SQL
- Other supported technologies / languages: None.
- Expected resolution time: 30 minutes.
