# SQL Challenge

Welcome to the WeDevelop Challenge! 🚀

## Description

- Use your local development environment.
- Use MySQL, Oracle, Microsoft SQL Server or Postgres for your solutions.

### Challenge 1

- Create table:
  
    ```sql
    CREATE TABLE shop (
        article INT UNSIGNED  DEFAULT '0000' NOT NULL,
        dealer  CHAR(20)      DEFAULT ''     NOT NULL,
        price   DECIMAL(16,2) DEFAULT '0.00' NOT NULL,
        PRIMARY KEY(article, dealer));
    INSERT INTO shop VALUES
        (1,'A',3.45),(1,'B',3.99),(2,'A',10.99),(3,'B',1.45),
        (3,'C',1.69),(3,'D',1.25),(4,'D',19.95);
    ```

1. What is the highest item number?
2. Find the number, dealer, and price of the most expensive article.
3. Find the highest price per article.
4. For each article, find the dealer or dealers with the most expensive price.
   1. Do it in two different ways, with and without using JOIN.
5. Use user-defined variables to find the articles with the highest and lowest price using user-defined variables.

### Chanllenge 2

- Create tables:

    ```sql
    CREATE DATABASE ORG;
    SHOW DATABASES;
    USE ORG;

    CREATE TABLE Worker (
    WORKER_ID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    FIRST_NAME CHAR(25),
    LAST_NAME CHAR(25),
    SALARY INT(15),
    JOINING_DATE DATETIME,
    DEPARTMENT CHAR(25)
    );

    INSERT INTO Worker 
    (WORKER_ID, FIRST_NAME, LAST_NAME, SALARY, JOINING_DATE, DEPARTMENT) VALUES
    (001, 'Monika', 'Arora', 100000, '14-02-20 09.00.00', 'HR'),
    (002, 'Niharika', 'Verma', 80000, '14-06-11 09.00.00', 'Admin'),
    (003, 'Vishal', 'Singhal', 300000, '14-02-20 09.00.00', 'HR'),
    (004, 'Amitabh', 'Singh', 500000, '14-02-20 09.00.00', 'Admin'),
    (005, 'Vivek', 'Bhati', 500000, '14-06-11 09.00.00', 'Admin'),
    (006, 'Vipul', 'Diwan', 200000, '14-06-11 09.00.00', 'Account'),
    (007, 'Satish', 'Kumar', 75000, '14-01-20 09.00.00', 'Account'),
    (008, 'Geetika', 'Chauhan', 90000, '14-04-11 09.00.00', 'Admin');


    CREATE TABLE Title (
    WORKER_REF_ID INT,
    WORKER_TITLE CHAR(25),
    AFFECTED_FROM DATETIME,
    FOREIGN KEY (WORKER_REF_ID)
    REFERENCES Worker(WORKER_ID)
            ON DELETE CASCADE
    );

    INSERT INTO Title 
    (WORKER_REF_ID, WORKER_TITLE, AFFECTED_FROM) VALUES
    (001, 'Manager', '2016-02-20 00:00:00'),
    (002, 'Executive', '2016-06-11 00:00:00'),
    (008, 'Executive', '2016-06-11 00:00:00'),
    (005, 'Manager', '2016-06-11 00:00:00'),
    (004, 'Asst. Manager', '2016-06-11 00:00:00'),
    (007, 'Executive', '2016-06-11 00:00:00'),
    (006, 'Lead', '2016-06-11 00:00:00'),
    (003, 'Lead', '2016-06-11 00:00:00');
    ```

1. Fetch worker names with salaries >= 50000 and <= 100000.
2. Use `join` to print details of the Workers who are also Manager.
3. Fetch duplicate records that have matching data in some fields in the Title table.
4. Write an SQL query to fetch the list of employees with the same salary.
5. Use `join` to print the name of employees having the highest salary in each department.

**Happy coding!**

## Notes for the interviewer

Sources:

1. <https://dev.mysql.com/doc/mysql-tutorial-excerpt/8.0/en/examples.html>
2. <https://www.techbeamers.com/sql-query-questions-answers-for-practice/>

### Evaluation method

### Positive response

#### Answers Challenge 1

1. What is the highest item number?

    ```sql
    SELECT MAX(article) AS article FROM shop;
    +---------+
    | article |
    +---------+
    |       4 |
    +---------+
    ```

2. Find the number, dealer, and price of the most expensive article.

    ```sql
    SELECT article, dealer, price
    FROM   shop
    WHERE  price=(SELECT MAX(price) FROM shop);
    +---------+--------+-------+
    | article | dealer | price |
    +---------+--------+-------+
    |    0004 | D      | 19.95 |
    +---------+--------+-------+
    ```

    Another solution is to use a LEFT JOIN, as shown here:

    ```sql
    SELECT s1.article, s1.dealer, s1.price
    FROM shop s1
    LEFT JOIN shop s2 ON s1.price < s2.price
    WHERE s2.article IS NULL;
    ```

    You can also do this by sorting all rows descending by price and get only the first row using the MySQL-specific LIMIT clause, like this:

    ```sql
    SELECT article, dealer, price
    FROM shop
    ORDER BY price DESC
    LIMIT 1;
    ```

    Note: If there were several most expensive articles, each with a price of 19.95, the LIMIT solution would show only one of them.

3. Find the highest price per article

    ```sql
    SELECT article, MAX(price) AS price
    FROM   shop
    GROUP BY article
    ORDER BY article;
    +---------+-------+
    | article | price |
    +---------+-------+
    |    0001 |  3.99 |
    |    0002 | 10.99 |
    |    0003 |  1.69 |
    |    0004 | 19.95 |
    +---------+-------+
    ```

4. For each article, find the dealer or dealers with the most expensive price.

    This problem can be solved with a subquery like this one:

    ```sql
    SELECT article, dealer, price
    FROM   shop s1
    WHERE  price=(SELECT MAX(s2.price)
                FROM shop s2
                WHERE s1.article = s2.article)
    ORDER BY article;
    +---------+--------+-------+
    | article | dealer | price |
    +---------+--------+-------+
    |    0001 | B      |  3.99 |
    |    0002 | A      | 10.99 |
    |    0003 | C      |  1.69 |
    |    0004 | D      | 19.95 |
    +---------+--------+-------+
    ```

    The preceding example uses a correlated subquery, which can be inefficient. Other possibilities for solving the problem are:
    - Uncorrelated subquery in the FROM clause:
  
        ```sql
        SELECT s1.article, dealer, s1.price
        FROM shop s1
        JOIN (
        SELECT article, MAX(price) AS price
        FROM shop
        GROUP BY article) AS s2
        ON s1.article = s2.article AND s1.price = s2.price
        ORDER BY article;
        ```

    - LEFT JOIN:
  
        ```sql
        LEFT JOIN:

        SELECT s1.article, s1.dealer, s1.price
        FROM shop s1
        LEFT JOIN shop s2 ON s1.article = s2.article AND s1.price < s2.price
        WHERE s2.article IS NULL
        ORDER BY s1.article;
        ```

        The LEFT JOIN works on the basis that when s1.price is at its maximum value, there is no s2.price with a greater value and thus the corresponding s2.article value is NULL. See JOIN Clause.

    - Common table expression with a window function:
  
        ```sql
        WITH s1 AS (
        SELECT article, dealer, price,
                RANK() OVER (PARTITION BY article
                                ORDER BY price DESC
                            ) AS `Rank`
            FROM shop
        )
        SELECT article, dealer, price
        FROM s1
        WHERE `Rank` = 1
        ORDER BY article;
        ```

5. Find the articles with the highest and lowest price using user-defined variables.

    ```sql
    mysql> SELECT @min_price:=MIN(price),@max_price:=MAX(price) FROM shop;
    mysql> SELECT * FROM shop WHERE price=@min_price OR price=@max_price;

    +---------+--------+-------+
    | article | dealer | price |
    +---------+--------+-------+
    |    0003 | D      |  1.25 |
    |    0004 | D      | 19.95 |
    +---------+--------+-------+
    ```

    Note: It is also possible to store the name of a database object such as a table or a column in a user variable and then to use this variable in an SQL statement; however, this requires the use of a prepared statement.

#### Answers Challenge 2

1. Ans:

    ```sql
    SELECT CONCAT(FIRST_NAME, ' ', LAST_NAME) As Worker_Name, Salary
    FROM worker 
    WHERE WORKER_ID IN 
    (SELECT WORKER_ID FROM worker 
    WHERE Salary BETWEEN 50000 AND 100000);
    ```

2. Ans:

    ```sql
    SELECT DISTINCT W.FIRST_NAME, T.WORKER_TITLE
    FROM Worker W
    INNER JOIN Title T
    ON W.WORKER_ID = T.WORKER_REF_ID
    AND T.WORKER_TITLE in ('Manager');
    ```

3. Ans:

    ```sql
    SELECT WORKER_TITLE, AFFECTED_FROM, COUNT(*)
    FROM Title
    GROUP BY WORKER_TITLE, AFFECTED_FROM
    HAVING COUNT(*) > 1;
    ```

4. Ans:

    ```sql
    Select distinct W.WORKER_ID, W.FIRST_NAME, W.Salary 
    from Worker W, Worker W1 
    where W.Salary = W1.Salary 
    and W.WORKER_ID != W1.WORKER_ID;
    ```

5. Ans:

    ```sql
    SELECT t.DEPARTMENT,t.FIRST_NAME,t.Salary from(SELECT max(Salary) as TotalSalary,DEPARTMENT from Worker group by DEPARTMENT) as TempNew 
    Inner Join Worker t on TempNew.DEPARTMENT=t.DEPARTMENT 
    and TempNew.TotalSalary=t.Salary;
    ```

### Extra points if

## Challenge metadata

- Level: 3-4-5
- Preferred technology / language: SQL
- Other supported technologies / languages: None.
- Expected resolution time: 30 minutes.
