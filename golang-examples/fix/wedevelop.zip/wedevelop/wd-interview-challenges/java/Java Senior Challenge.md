# Java Senior Challenge:

## Description

Please answer the next questions:

INFRA

- Docker
- Kubernetes
- CI/CD
- GitHub (or another repos)
- Git Workflows
  - Git Feature Branch Workflow
  - Forking Workflow
  - Gitflow Workflow
- Cloud Services
  - AWS
  - GCP
  - Digital Ocean
  - Firebase

1.  What are the types of storage services apart from blob storage provided by Azure?
    Azure provides overall 4 types of storage services - Blob Service, Table Storage, Queue Storage, and File Storage Services.
    Azure Table Storage: This type of storage lets user deploy their applications with semi-structured data and a NoSQL-based key-value store.
    This is used when there is a need for applications that follow a flexible schema of data.
    Table Storage focuses on enterprise-level data and follows strongly consistent models.
    The data is represented in terms of Entities grouped under tables.
    Azure Queue Storage: This storage provides a message queue system for handling large workloads by letting users develop and build flexible and modular applications.
    This storage ensures that the application becomes less prone to failure of individual components and is scalable.
    With the help of message queues, it provides the queue monitoring feature for helping the application to ensure the user demands are met.
    Azure File Storage: This storage type provides features of file sharing that are accessible using SMB (Server Message Block) Protocol. The data in this storage is protected by HTTPS and SMB 3.0 Protocol.
    They are used for improving the performance and capabilities of on-premise applications.
    The OS deployments and hardware management is taken by Azure itself.


- What are IaaS, PaaS and SaaS?
    IaaS: This stands for “Infrastructure as a Service” which provides a set of capabilities like OS, network connectivities, etc which are at the infrastructural level and are delivered as pay per use policy. The infrastructure is used for hosting applications. Examples include Azure VM, VNET, etc.

    PaaS: PaaS stands for “Platform as a Service” which is mostly about underlying infrastructure abstraction to the developers for enabling quicker development of the applications without the need for worry about hosting management. Examples include Azure web apps, Storage services, cloud services, etc.

    SaaS: SaaS stands for “Software as a Service” and are those applications which are delivered using the service delivery model where the applications are simply consumed and used by an organization. These applications are generally mobilized by making the organization pay for their usage or through ads. Examples include applications like Office 365, Gmail, SharePoint Online, and so on.

3. What chat you tell me about the clould computign model "Serverless" ?(lambdas, cloud functions, etc).
    Serverless computing is a cloud computing execution model in which the cloud provider allocates machine resources on demand, taking care of the servers on behalf of their customers. "Serverless" is a misnomer in the sense that servers are still used by cloud service providers to execute code for developers.

4. SQL 


https://codeshare.io/vwNA67

## Payload

## Notes for the interviewer

For Siggi

### Evaluation method

### Positive response

### Extra points if

## Challenge metadata
- Level: 0
- Preferred technology / language: Javascript
- Other supported technologies / languages: Any.
- Expected resolution time: 10 minutes.