## Challenge metadata




# Title

## Description



## Payload

## Notes for the interviewer

### Evaluation method

### Positive response

### Extra points if

## Challenge metadata
- Level: 0
- Preferred technology / language: Javascript
- Other supported technologies / languages: Any.
- Expected resolution time: 10 minutes.











This article is about the SOLID principles of object-oriented programming. For the fundamental state of matter, see Solid. For other uses, see Solid (disambiguation).
SOLID
Principles
Single responsibility
Open–closed
Liskov substitution
Interface segregation
Dependency inversion
vte
In software engineering, SOLID is a mnemonic acronym for five design principles intended to make software designs more understandable, flexible, and maintainable. The principles are a subset of many principles promoted by American software engineer and instructor Robert C. Martin,[1][2][3] first introduced in his 2000 paper Design Principles and Design Patterns.[2][4]

The SOLID ideas are

The single-responsibility principle: "There should never be more than one reason for a class to change."[5] In other words, every class should have only one responsibility.[6]
The open–closed principle: "Software entities ... should be open for extension, but closed for modification."[7]
The Liskov substitution principle: "Functions that use pointers or references to base classes must be able to use objects of derived classes without knowing it."[8] See also design by contract.[8]
The interface segregation principle: "Many client-specific interfaces are better than one general-purpose interface."[9][4]
The dependency inversion principle: "Depend upon abstractions, [not] concretions."[10][4]



- OOP 
- Pattern.
- Antipatterns.
- Architecture.
- Testing.
- Development philosophies.
- Debbing methodoogies


Saber cuánto tiempo real de exp tienen con Java.
Si son capos en DevOps / Infraestructura.



AZURE



Azure Table Storage: This type of storage lets user deploy their applications with semi-structured data and a NoSQL-based key-value store.
This is used when there is a need for applications that follow a flexible schema of data.
Table Storage focuses on enterprise-level data and follows strongly consistent models.
The data is represented in terms of Entities grouped under tables.
Azure Queue Storage: This storage provides a message queue system for handling large workloads by letting users develop and build flexible and modular applications.
This storage ensures that the application becomes less prone to failure of individual components and is scalable.
With the help of message queues, it provides the queue monitoring feature for helping the application to ensure the user demands are met.
Azure File Storage: This storage type provides features of file sharing that are accessible using SMB (Server Message Block) Protocol. The data in this storage is protected by HTTPS and SMB 3.0 Protocol.
They are used for improving the performance and capabilities of on-premise applications.
The OS deployments and hardware management is taken by Azure itself.






Ideal que sea con Azure.


eso como primario. Secundario:
Años de exp con: SpringBoot,

REST APIs, 
Git,
Microservicios.


S
The four pillars of object-oriented programming are:

Abstraction
Encapsulation
Inheritance
Polymorphism
Let's take a closer look at each of them.

