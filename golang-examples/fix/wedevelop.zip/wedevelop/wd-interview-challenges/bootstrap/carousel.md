# Carousel

## Description

- Using Bootstrap and JQuery create a carousel like the on the picture:
  - Carousel: <https://imgur.com/a/hL0IyWc>
  - Carousel picture: <https://cdn.pixabay.com/photo/2017/02/08/14/25/computer-2048983_960_720.jpg>

**Happy coding!**

---

## Notes for the interviewer

### Evaluation method

De aqui saco los snippets:

<https://bootsnipp.com/>
<https://css-tricks.com/snippets/jquery/>

### Positive response

### Extra points if

## Challenge metadata

- Level: 3
- Preferred technology / language: Boostrap/JQuery.
- Other supported technologies / languages: None.
- Expected resolution time: 10 minutes.
