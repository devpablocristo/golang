# Bookstore Users

Welcome to the WeDevelop Challenge! 🚀

## Description

- Create a REST API app for a bookstore.
- Use you own development environment.
- Databases are NOT required (except by the `(Extra point)`.

Consider we have a JSON based database of users having the following users:

```json
{
   "user1" : {
      "name" : "John",
      "password" : "password1",
      "profession" : "teacher",
      "id": 1
   },
   
   "user2" : {
      "name" : "Pedro",
      "password" : "password2",
      "profession" : "librarian",
      "id": 2
   },
   
   "user3" : {
      "name" : "Ramesh",
      "password" : "password3",
      "profession" : "clerk",
      "id": 3
   }
}
```

### Tasks

1. List users.
2. Add a user.
3. Get a user.
4. Delete a user.
5. `(Extra point)`: Create a unit test.
6. `(Extra point)`: Use a SQL or a NoSQL DB for data persistence.

## Payload

```js
ar express = require('express');
var app = express();
var fs = require("fs");

app.get('/listUsers', function (req, res) {
})

app.post('/addUser', function (req, res) {
})

app.get('/:id', function (req, res) {
})

app.delete('/deleteUser', function (req, res) {
})

var server = app.listen(8081, function () {
   var host = server.address().address
   var port = server.address().port
   console.log("Example app listening at http://%s:%s", host, port)
})
```

**Happy coding!**

## Notes for the interviewer

Sources:

1. <https://www.tutorialspoint.com/nodejs/nodejs_restful_api.htm>

### Evaluation method

### Positive response

```js
ar express = require('express');
var app = express();
var fs = require("fs");

app.get('/listUsers', function (req, res) {
   fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
      console.log( data );
      res.end( data );
   });
})

app.post('/addUser', function (req, res) {
   // First read existing users.
   fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
      data = JSON.parse( data );
      data["user4"] = user["user4"];
      console.log( data );
      res.end( JSON.stringify(data));
   });
})

app.get('/:id', function (req, res) {
   // First read existing users.
   fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
      var users = JSON.parse( data );
      var user = users["user" + req.params.id] 
      console.log( user );
      res.end( JSON.stringify(user));
   });
})

app.delete('/deleteUser', function (req, res) {
   // First read existing users.
   fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
      data = JSON.parse( data );
      delete data["user" + 2];
       
      console.log( data );
      res.end( JSON.stringify(data));
   });
})

var server = app.listen(8081, function () {
   var host = server.address().address
   var port = server.address().port
   console.log("Example app listening at http://%s:%s", host, port)
})
```

### Extra points if

## Challenge metadata

- Level: 3-4-5
- Preferred technology / language: Node.js, Javascript
- Other supported technologies / languages: Any.
- Expected resolution time: 10 minutes.
