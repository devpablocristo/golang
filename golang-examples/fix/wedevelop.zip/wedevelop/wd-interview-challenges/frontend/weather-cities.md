https://api.openweathermap.org/data/2.5/weather?lat=5&lon=19&appid=2fedb4e6d1d63b1ae0001830adf6d26f

https://api.openweathermap.org/data/2.5/weather?q=new%20york&appid=2fedb4e6d1d63b1ae0001830adf6d26f