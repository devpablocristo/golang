# Get and display the API elements

Welcome to the WeDevelop Challenge! 🚀

## Description

- Create an app for a bookstore.
- Use your local development environment.

### Tasks

1. Display the API elements:
   1. Book title.
   2. Book price.
   3. Book image.
2. Add button to mark a book as favorite.
3. Apply styles, follow the given designs.
4. `(Extra point)`: Add button to list all favorites. Save favorites with redux or context API.
5. `(Extra point)`: Create a unit test.

API: <https://api.itbook.store/1.0/new>
Designs: <https://imgur.com/a/UgnKlXb>

**Happy coding!**

## Notes for the interviewer

### Evaluation method

**3 - SSR:** Puntos 1,2 y 3 correctos.
**4 - SSR Upper:** Puntos 1,2,3 y 4 correctos.
**5 - SSR Upper:** Todos los puntos correctos.### Positive response

### Extra points if

## Challenge metadata

- Level: 3-4-5
- Preferred technology: Frontend.
- Expected resolution time: 10 minutes.
