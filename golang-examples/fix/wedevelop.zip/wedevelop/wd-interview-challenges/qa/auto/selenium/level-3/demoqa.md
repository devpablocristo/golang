# demoqa.com

## Description

[demoqa.com](https://demoqa.com) is a basic demo site.

It contains training modules like contact forms, menus to select, buttons to click, etc.

Only chosen features on the sections:

- `Interactions section:` <https://demoqa.com/interaction>
- `Widgets section:` <https://demoqa.com/widgets>

Are going to be tested.

## Payload

### Features to be tested

The features to be tested are under this two links:

| Module | Description |
| ----- | --------- |
| `Interactions section:` |
| Selectable | A list of items which can be selected |
| Resizable | An element which can be resized with dragging the mouse: height, width or both at once |
| Droppable | An element which can be dragged to a target element |
| `Widgets section:` |
| HTML contact form | A contact form with textfields, links and submit button |
| Keyboard Events | A file upload demo |
| Tooltip and Double click | A double click button, a right-click button and a hover |
| Slider | A slider bar |
| Dialog | A dialog window which can be moved, resized and closed |
| Datepicker | A text field with calendar |
| Checkboxradio | A radio checkbox and multi choice checkboxes |

### Features NOT to be tested

- Interactions section:
  - Sortable
  - Draggable
- Widgets section:
  - Automation Practice Switch Windows
  - Keyboard Events Sample Form
  - Tooltip
  - Tabs
  - Spinner
  - Selectmenu
  - Progressbar
  - Menu
  - Controlgroup
  - Button
  - Autocomplete
  - Accordion

### Test type

The test type is a functional module testing.
All modules are tested separately.

**Happy testing!**

## Notes for the interviewer

Original project: <https://github.com/agafun/demoqa-tests>
Solution: <https://github.com/agafun/demoqa-tests/blob/master/test-suite.md>

### Evaluation method

#### Functional testing

Is a process and a type of black-box testing that bases its test cases on the specifications of the software component under test. Functions are tested by feeding them input and examining the output, and internal program structure is rarely considered (unlike white-box testing). Functional testing is conducted to evaluate the compliance of a system or component with specified functional requirements. Functional testing usually describes what the system does.

Since functional testing is a type of black-box testing, the software's functionality can be tested without knowing the internal workings of the software. This means that testers do not need to know programming languages or how the software has been implemented. This, in turn, could lead to reduced developer bias (or confirmation bias) in testing since the tester has not been involved in the software's development.[

Functional testing does not imply that you are testing a function (method) of your module or class. Functional testing tests a slice of functionality of the whole system.

Functional testing differs from system testing in that functional testing "verifies a program by checking it against ... design document(s) or specification(s)", while system testing "validate[s] a program by checking it against the published user or system requirements."

### Positive response

There are 38 test cases with expected results.

**Module**|**ID**|**Action**|**Expected result**|**Result**|**Reproduction steps**|**Problem/error**
-----|-----|-----|-----|-----|-----|-----
Title, internal and external links|1|Check the title of demoqa.com|After opening demoqa.com you get the title `ToolsQA – Demo Website to Practice Automation – Demo Website to Practice Automation`|OK|1. Go to the website demoqa.com;<br> 2. Get the title of the website;|  
 ||2|Test 1 internal link on top menu|Internal link on top menu `Interactions` links to the site `https://demoqa.com/category/interactions/`|OK|1. Go to the website demoqa.com;<br> 2. Click the link on top menu `Interactions`;|
 ||3|Test 1 internal link on sidebar in Interactions section|Internal link on sidebar in Interactions section `Resizable` links to the site `https://demoqa.com/resizable/`|OK|1. Go to the website demoqa.com;<br> 2. Click the link on sidebar `Resizable`;|
 ||4|Test 1 internal link on sidebar in Widgets section|Internal link on sidebar in Widgets section `Tooltip` links to thet site `https://demoqa.com/tooltip/`|OK|1. Go to the website demoqa.com;<br> 2. Click the link on sidebar `Tooltip`;|
 ||5|Check the external link to toolsqa.com|The external link on the header links to toolsqa.com |OK|1. Go to the website demoqa.com;<br> 2. Click the link on the header;|
Interactions section:| | | | | |
Selectable|6|Select Item 1|After selecting Item 1, Item 1 is highlighted in orange|OK|1. Go to the website <https://demoqa.com/selectable/>;<br> 2. Click Item 1 on the selectable list;|
 ||7|Select Item 7|After selecting Item 7, Item 7 is highlighted in orange|OK|1. Go to the website <https://demoqa.com/selectable/>;<br> 2. Click Item 7 on the selectable list;|
 ||8|Select Item 1, 2 and 3 with ctrl/cmd button|After selecting Item 1, 2 and 3 with ctrl/cmd button, Item 1, 2 and 3 are highlighted in orange|OK|1. Go to the website <https://demoqa.com/selectable/>;<br> 2. Press ctrl/cmd button;<br> 3. Click Item 1 on the selectable list;<br> 4. Click Item 2 on the selectable list;<br> 5. Click Item 3 on the selectable list;<br> 6. Release ctrl/cmd button;|
 ||9|Select Item 1, 2 and 3 with ctrl/cmd button and deselect Item 2|After selecting Item 1, 2 and 3 with ctrl/cmd button and deselecting Item 2, only Item 1 and 3 are highlighted in orange|OK|1. Go to the website <https://demoqa.com/selectable/>;<br> 2. Press ctrl/cmd button;<br> 3. Click Item 1 on the selectable list;<br> 4. Click Item 2 on the selectable list;<br> 5. Click Item 3 on the selectable list;<br> 6. Click Item 2 on the selectable list;<br> 7. Release ctrl/cmd button;|
 ||10|Select Item 1, 2 and 3 with ctrl/cmd button and select Item 1 once again|After selecting Item 1, 2 and 3 with ctrl/cmd button and selecting Item 1 once again, only Item 1 is highlighted in orange|OK|1. Go to the website <https://demoqa.com/selectable/>;<br> 2. Press ctrl/cmd button;<br> 3. Click Item 1 on the selectable list;<br> 4. Click Item 2 on the selectable list;<br> 5. Click Item 3 on the selectable list;<br> 6. Release ctrl/cmd button;<br> 7. Click Item 1 on the selectable list;|
 ||11|Select Item 4 to 7 by dragging a mouse|After selecting Item 4 to 7 by dragging a mouse, Item 4, 5, 6 and 7 are highlighted in orange|OK|1. Go to the website <https://demoqa.com/selectable/>;<br> 2. Drag a mouse through Item 4, Item 5, Item 6 and Item 7 on the selectable list;|
 ||12|Select Item 4 to 7 by dragging a mouse and select Item 7 once again|After selecting Item 4 to 7 by dragging a mouse and selecting Item 7 once again, only Item 7 is highlighted in orange|OK|1. Go to the website <https://demoqa.com/selectable/>;<br> 2. Drag a mouse through Item 4, Item 5, Item 6 and Item 7 on the selectable list;<br> 3. Click Item 7 on the selectable list;|
Resizable|13|Resize the element horizontally|The element is resized horizontally by 100 px|NOT OK|1. Go to the website <https://demoqa.com/resizable/>;<br> 2. Drag a mouse from the right side of the element by 100 px to the right;|Assertion error; the element’s size always differs by 17 px
 ||14|Resize the element vertically|The element is resized horizontally by 200 px|NOT OK|1. Go to the website <https://demoqa.com/resizable/>;<br> 2. Drag a mouse from the bottom side of the element by 100 px down;|Assertion error; the element’s size always differs by 17 px
 ||15|Resize the element diagonally|The element is resized diagonally to the minimum size|NOT OK|1. Go to the website <https://demoqa.com/resizable/>;<br> 2. Drag a mouse diagonally left-up from the right-bottom corner of the element to it’s minimum size;|Assertion error; the element’s size always differs by 17 px
Droppable|16|Drag the element to the target|After dragging the element to the target the element is within the target square and the target square is colored yellow with inscription „Dropped!”|OK|1. Go to the website <https://demoqa.com/droppable/>;<br> 2. Drag the element to the target;|
 ||17|Drag the element not to the target|After dragging the element not to the target the element is placed on release point and the target square is colored gray with inscription „Drop here”|OK|1. Go to the website <https://demoqa.com/droppable/>;<br> 2. Drag the element not to the target;|
 ||18|Drag the element not whole to the target|After dragging the element not whole to the target the element is placed on release point and the target square is colored gray with inscription „Drop here”|OK|1. Go to the website <https://demoqa.com/droppable/>;<br> 2. Drag the element to whole the target;|
Widgets section:| | | | | |
HTML contact form|19|Fill the form with First Name, Last Name, Country, and Subject, and click Submit|After clicking Submit button you should be redirected to a search website and the url address should contain value of Country and Subject as parameters|OK|1. Go to the website <https://demoqa.com/html-contact-form/>;<br> 2. Fill in First Name `Ala`;<br> 3. Fill in Last Name `Makota`;<br> 4. Fill in Country `Poland`;<br> 5. Fill in Subject `Hello`;<br> 6. Click Submit button;<br> 7. Get the url of the new website;|
 ||20|Fill the form with First Name, Last Name, Country, and Subject using special characters, and click Submit|After clicking Submit button you should be redirected to a search website and the url address should contain value of Country and Subject as parameters despite special characters|OK|1. Go to the website <https://demoqa.com/html-contact-form/>;<br> 2. Fill in First Name `Ala`;<br> 3. Fill in Last Name `Makota`;<br> 4. Fill in Country `P0l4nd`;<br> 5. Fill in Subject `%&*`;<br> 6. Click Submit button;<br> 7. Get the url of the new website;|
Keyboard Events|21|Choose a file and click to upload - check the file path|After choosing a file and clicking `Click to Upload` button you should see a window with file path: `C:\fakepath\file-upload.png` |OK|1. Go to the website <https://demoqa.com/keyboard-events/>;<br> 2. Click Browse file and select `file-upload.png`;<br> 3. Click `Click to Upload` button;|
Tooltip and Double click|22|Double click on double click button|After double click on double click button you should see an alert window |OK|1. Go to the website <https://demoqa.com/tooltip-and-double-click/>;<br> 2. Double click `Hello, Double-click me` button;<br> 3. Close the alert window;|
 ||23|Right-click on right-click button and select an element from menu|After right-click on right-click button you should see a select menu|NOT OK|1. Go to the website <https://demoqa.com/tooltip-and-double-click/>;<br> 2. Right click `Right-click` button;<br> 3. Select and click on `Copy me`;<br> 4. Close the alert window;|NoSuchAlertError: no such alert
 ||24|Hover over hover element|After hovering over hover element you should see a tooltip|OK|1. Go to the website <https://demoqa.com/tooltip-and-double-click/>;<br> 2. Move the mouse over `Hover over me to see tooltip`;|
Slider|25|Slide the slider by dragging a mouse|Slider moves by dragging a mouse to the release point|OK|1. Go to the website <https://demoqa.com/slider/>;<br> 2. Move the slider by dragging a mouse to the release point;|
 ||26|Slide the slider by clicking on a bar|Slider moves by clicking a bar to the click point|OK|1. Go to the website <https://demoqa.com/slider/>;<br> 2. Move the slider by clicking on a slide bar;|
Dialog|27|Move the dialog window by dragging a mouse|Dialog window moves to the release point|OK|1. Go to the website <https://demoqa.com/dialog/>;<br> 2. Move the dialog window by dragging a mouse to the left-up corner of the website;|
 ||28|Resize the dialog window horizontally and vertically in all four directions|Size of dialog window is changed horizontally and vertically in all four directions|OK|1. Go to the website <https://demoqa.com/dialog/>;<br> 2. Drag the right side of the element by 100 px to the right;<br> 3. Drag the left side of the element by 100 px to  the left;<br> 4. Drag the upper side of the element by 100 px up;<br> 5. Drag the bottom side of the element by 100 px down;|The element’s size always differs from calculations
 ||29|Resize the dialog window diagonally in four directions|Size of dialog window is changed diagonally in all four directions|OK|1. Go to the website <https://demoqa.com/dialog/>;<br> 2. Drag the right-down corner of the element by 100 px to the right and 100 px down;<br> 3. Drag the right-up corner of the element by 100 px to the right and 100 px up;<br> 4. Drag the left-down corner of the element by 100 px to the left and 100 px down;<br> 5. Drag the left-up corner of the element by 100 px to the left and 100 px up;|The element’s size always differs from calculations
 ||30|Close the dialog window with `x` icon|After closing the dialog window with `x` icon, the window is not visible any more|OK|1. Go to the website <https://demoqa.com/dialog/>;<br> 2. Click the `x` icon;|
Datepicker|31|Check if the today’s date is highlighted|After clicking on input field, you should see a calendar with highlighted today’s date|OK|1. Go to the website <https://demoqa.com/datepicker/>;<br> 2. Click on the input field; 3. Check if the highlighted date is today’s date;|
 ||32|Choose the today’s date in calendar|After choosing the today’s date in calendar, you should see a today’s date in input field in format mm/dd/yyyy|OK|1. Go to the website <https://demoqa.com/datepicker/>;<br> 2. Click on the input field;<br> 3. Click on highlighted date;|Add an assert which checks date format
 ||33|Write a date in format 12/21/2019|After writing a date in format 12/21/2019 you should see a calendar with highlighted date 21/12/2019|OK|1. Go to the website <https://demoqa.com/datepicker/>;<br> 2. Write the date 12/21/2019 in the input field;|
 ||34|Write date 01/14/0030 and check the calendar’s header|After writing a date in format 01/14/0030 you should see a calendar with highlighted date 21/12/2030|OK|1. Go to the website <https://demoqa.com/datepicker/>;<br> 2. Write the date 01/14/0030 in the input field;|
 ||35|Write date 01/14/0031 and check the calendar’s header|After writing a date in format 01/14/0031 you should see a calendar with highlighted date 21/12/1931|OK|1. Go to the website <https://demoqa.com/datepicker/>;<br> 2. Write the date 01/14/0031 in the input field;|
Checkboxradio|36|Select New York, Paris and London in Radio Group|After selecting New York, Paris and London in Radio Group only London is selected|OK|1. Go to the website <https://demoqa.com/checkboxradio/>;<br> 2. Click on `New York` in Radio Group;<br> 3. Click on `Paris` in Radio Group;<br> 4. Click on `London` in Radio Group;|
 ||37|Check box 2 Star, 3 Star, 4 Star and 5 Star and uncheck 4 Star in Checkbox|After checking 2 Star, 3 Star, 4 Star and 5 Star and unchecking 4 Star in Checkbox only 2 Star, 3 Star and 5 Star are checked|OK|1. Go to the website <https://demoqa.com/checkboxradio/>;<br> 2. Click on `2 Star` in Checkbox;<br> 3. Click on `3 Star` in Checkbox;<br> 4. Click on `4 Star` in Checkbox;<br> 5. Click on `5 Star` in Checkbox;<br> 6. Click on `4 Star` in Checkbox;|
 ||38|Check box 2 Double, 2 Queen, 1 Queen, 1 King and uncheck 2 Double in Checkbox nested in label|After checking 2 Double, 2 Queen, 1 Queen, 1 King and unchecking 2 Double in Checkbox only 2 Queen, 1 Queen and 1 King are checked|OK|1. Go to the website <https://demoqa.com/checkboxradio/>;<br> 2. Click on `2 Double` in Checkbox nested;<br> 3. Click on `2 Queen` in Checkbox nested;<br> 4. Click on `1 Queen` in Checkbox nested;<br> 5. Click on `1 King` in Checkbox nested;<br> 6. Click on `2 Double` in Checkbox nested;|

### Extra points if

- Ask for the used methods.
- This is are a list of them (idk if this just for JS or any language)

```
get()
getTitle()
getCurrentUrl()
getAttribute()
getText()
findElement()
click()
sendKeys()
switchTo()
```

or methods from Actions class:

```
keyDown()
keyUp()
dragAndDrop()
doubleClick()
contextClick()
move()
```

## Challenge metadata

- Level: 3
- Preferred technology: Selenium / language: Node.js, Python, Ruby, Java, Kotlin, C#.
- Other supported technologies / languages: Any.
- Expected resolution time: 30 minutes.
