# API Automation

## Description

You have to implement the following Web automated checks over this DEMO WEB PAGE: <https://pokeapi.co/>

· Go to the API web page.
· Test on the page the response to get based on the API path to get Pokémon’s  names.
· Create an API test to Validate its Status (200) for a Pokémon “Bulbasaur”.
· Create a validation test to verify the name of Pokémon # 10 is equal to “caterpie”.
· Create an API test to Validate its Status (404) for a Pokémon number that does not exist.

**Happy testing!**

## Payload

## Notes for the interviewer

### Evaluation method

### Positive response

### Extra points if

## Challenge metadata
