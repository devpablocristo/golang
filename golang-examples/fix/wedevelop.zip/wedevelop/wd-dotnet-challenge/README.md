# Welcome to the WeDevelop .NET challenge 🚀

## Requirements

1. Clone the project.
2. Use the existing project to complete the tasks.

## Happy Coding!
