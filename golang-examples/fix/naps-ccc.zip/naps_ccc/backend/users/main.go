package main

import (
	"github.com/devpablocristo/users/app"
)

func main() {
	// en app/app.go
	app.StartApp()
}
