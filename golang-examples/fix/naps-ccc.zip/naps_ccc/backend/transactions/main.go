package main

import (
	"github.com/devpablocristo/transactions/app"
)

func main() {
	// en app/app.go
	app.StartApp()
}
