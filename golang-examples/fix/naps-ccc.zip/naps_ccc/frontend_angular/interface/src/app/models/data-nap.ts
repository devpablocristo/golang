export interface DataNap {
    id_nodo_arbol?: number;
    descripcion?: string;
    latitud?: string;
    longitud?: string;
    disponibles?: number;
}
