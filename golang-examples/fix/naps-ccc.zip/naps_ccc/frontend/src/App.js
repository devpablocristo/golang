import React from 'react';
import './app.css'
import { AppRouter } from './components/routers/AppRouter';


export const App = () => {

  return (
            <AppRouter/>
  )
}


