1. Desde LibreOffice Calc, al archivo de las sucursales, guardar como cvs.
2. Desde la web copiar todos los datos: http://www.viaccc.com/FormasPago.aspx
3. Guardar como csv desde LibreOffice Calc.
4. Eliminar si existen previas bases de datos con los nombres:
    1. web_sucursales_nuevas
    2. web_sucursales_viejas
5. Importar desde phpMyAdmin, seleccionar “la primera linea tiene el nombre de las columnas”.
6. Guardar como:
    1. web_sucursales_nuevas
    2. web_sucursales_viejas
7. Cambiar el nombre desde workbench.
8. Usar los queries guardados.

Fin