1. Desde LibreOffice Calc, al archivo de las sucursales, guardar como cvs.
2. Desde la web copiar todos los datos: http://www.viaccc.com/FormasPago.aspx
3. Guardar como csv desde LibreOffice Calc.
    Ambos en con la confi de 2 columnas: domicilios - localidades
4. Guardar como "nuevos.csv" y "viejos.csv", repectivamente.
5. Correr y reemplazar valores.

Fin