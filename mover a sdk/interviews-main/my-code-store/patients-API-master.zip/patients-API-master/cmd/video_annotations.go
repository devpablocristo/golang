package main

func annotations() {

	/*
		package cmd: entrypoint - package main and function main
		package internal: cannot import an internal package

	*/

}
