#!/bin/bash

# git config --global user.name "ext-pacristo_meli" && git config --global user.email "ext_pacristo@mercadolibre.com"
# git config --global user.name "devpablocristo" && git config --global user.email "devpablocristo@gmail.com"

git config user.name "ext-pacristo_meli" && git config user.email "ext_pacristo@mercadolibre.com"
# git config user.name "devpablocristo" && git config user.email "devpablocristo@gmail.com"

git config user.name && git config user.email

code /home/pablo/.ssh/config
code /home/pablo/.gitconfig
# code repo/.git/config para correr este hay que estar dentro del repo
code /home/pablo/.zshrc
code /home/pablo/.bashrc
code /home/pablo/.bash_profile

echo "quitar o agregar -m o -p ejemplo: git@github.com-m:melisource/project.git"
