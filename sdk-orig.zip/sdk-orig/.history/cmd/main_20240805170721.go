package main

import (
	"log"

	monitoring "github.com/devpablocristo/golang/sdk/cmd/rest/monitoring/routes"
	user "github.com/devpablocristo/golang/sdk/cmd/rest/user/routes"
	cnsl "github.com/devpablocristo/golang/sdk/internal/platform/consul"
	ginsetup "github.com/devpablocristo/golang/sdk/internal/platform/gin"
	gmwsetup "github.com/devpablocristo/golang/sdk/internal/platform/go-micro-web"
	is "github.com/devpablocristo/golang/sdk/pkg/init-setup"
)

func main() {
	if err := is.InitSetup(); err != nil {
		log.Fatalf("Error setting up configurations: %v", err)
	}
	is.LogInfo("Application started with JWT secret key: %s", is.GetJWTSecretKey())
	is.MicroLogInfo("Starting application...")

	consul, err := cnsl.NewConsulInstance()
	if err != nil {
		is.MicroLogError("error initializing Consul: %v", err)
	}

	gomicro, err := gmw.NewGoMicroInstance(consul)
	if err != nil {
		is.MicroLogError("error initializing Go Micro: %v", err)
	}

	gingonic, err := gin.NewGinInstance()
	if err != nil {
		is.MicroLogError("error initializing Gin: %v", err)
	}

	monitoring.Routes(gingonic, gomicro)

	r := gingonic.GetRouter()

	user.Routes(r)

	gomicro.GetService().Handle("/", r)

	if err := gomicro.GetService().Run(); err != nil {
		is.MicroLogError("error starting Gin server: %v", err)
	}

}
