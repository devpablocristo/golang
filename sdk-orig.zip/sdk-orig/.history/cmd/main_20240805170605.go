package main

import (
	"log"

	// Importar paquetes necesarios
	monitoring "github.com/devpablocristo/golang/sdk/cmd/rest/monitoring/routes"
	user "github.com/devpablocristo/golang/sdk/cmd/rest/user/routes"
	cnsl "github.com/devpablocristo/golang/sdk/internal/platform/consul"
	ginsetup "github.com/devpablocristo/golang/sdk/internal/platform/gin"
	gmw "github.com/devpablocristo/golang/sdk/internal/platform/go-micro-web"
	is "github.com/devpablocristo/golang/sdk/pkg/init-setup"
)

func main() {
	// Inicializar configuración de la aplicación
	if err := is.InitSetup(); err != nil {
		log.Fatalf("Error setting up configurations: %v", err)
	}
	is.LogInfo("Application started with JWT secret key: %s", is.GetJWTSecretKey())
	is.MicroLogInfo("Starting application...")

	// Inicializar los servicios principales
	consulClient, goMicroService, ginRouter, err := initializeServices()
	if err != nil {
		is.MicroLogError("Error initializing services: %v", err)
		return
	}

	// Configurar rutas de la aplicación
	configureRoutes(ginRouter, goMicroService)

	// Ejecutar el servicio de Go Micro
	if err := goMicroService.GetService().Run(); err != nil {
		is.MicroLogError("Error starting Go Micro server: %v", err)
	}
}

// initializeServices inicializa Consul, Go Micro y Gin
func initializeServices() (cnsl.ConsulClientPort, gmw.GoMicroClientPort, *ginsetup.GinInstance, error) {
	// Inicializar Consul
	consulClient, err := cnsl.NewConsulInstance()
	if err != nil {
		return nil, nil, nil, err
	}

	// Inicializar Go Micro
	goMicroService, err := gmw.NewGoMicroInstance(consulClient)
	if err != nil {
		return nil, nil, nil, err
	}

	// Inicializar Gin
	ginRouter, err := ginsetup.NewGinInstance()
	if err != nil {
		return nil, nil, nil, err
	}

	return consulClient, goMicroService, ginRouter, nil
}

// configureRoutes configura las rutas de la aplicación
func configureRoutes(gin *ginsetup.GinInstance, goMicro gmw.GoMicroClientPort) {
	// Configurar rutas de monitoreo
	monitoring.Routes(gin, goMicro)

	// Obtener el router de Gin
	router := gin.GetRouter()

	// Configurar rutas de usuario
	user.Routes(router)

	// Registrar el router en el servicio Go Micro
	goMicro.GetService().Handle("/", router)
}
