package main

import (
	"log"

	is "github.com/devpablocristo/golang/sdk/pkg/init-setup"

	// Importar las rutas necesarias
	monitoring "github.com/devpablocristo/golang/sdk/cmd/rest/monitoring/routes"
	user "github.com/devpablocristo/golang/sdk/cmd/rest/user/routes"

	// Importar plataformas necesarias
	cnsl "github.com/devpablocristo/golang/sdk/internal/platform/consul"
	ginPlatform "github.com/devpablocristo/golang/sdk/internal/platform/gin"
	gmw "github.com/devpablocristo/golang/sdk/internal/platform/go-micro-web"
)

// main es el punto de entrada de la aplicación
func main() {
	// Inicializar la configuración y el entorno
	if err := is.InitSetup(); err != nil {
		log.Fatalf("Error setting up configurations: %v", err)
	}
	is.LogInfo("Application started with JWT secret key: %s", is.GetJWTSecretKey())
	is.MicroLogInfo("Starting application...")

	// Inicializar Consul
	consul, err := initializeConsul()
	if err != nil {
		is.MicroLogError("Error initializing Consul: %v", err)
		return
	}

	// Inicializar Go Micro
	gomicro, err := initializeGoMicro(consul)
	if err != nil {
		is.MicroLogError("Error initializing Go Micro: %v", err)
		return
	}

	// Inicializar Gin
	gingonic, err := initializeGin()
	if err != nil {
		is.MicroLogError("Error initializing Gin: %v", err)
		return
	}

	// Configurar rutas
	configureRoutes(gingonic, gomicro)

	// Ejecutar el servicio Go Micro
	if err := gomicro.GetService().Run(); err != nil {
		is.MicroLogError("Error starting Go Micro server: %v", err)
	}
}

// initializeConsul inicializa el cliente Consul
func initializeConsul() (cslhash.ConsulClientPor,	, error) {
	consul, err := cnsl.NewConsulInstance()
	if err != nil {
		return nil, err
	}
	return consul, nil
}

// initializeGoMicro inicializa el servicio Go Micro
func initializeGoMicro(consul cnsl.ConsulClientPort) (gmw.GoMicroClientPort, error) {
	gomicro, err := gmw.NewGoMicroInstance(consul)
	if err != nil {
		return nil, err
	}
	return gomicro, nil
}

// initializeGin inicializa el framework Gin
func initializeGin() (*ginPlatform.GinInstance, error) {
	gingonic, err := ginPlatform.NewGinInstance()
	if err != nil {
		return nil, err
	}
	return gingonic, nil
}

// configureRoutes configura las rutas de la aplicación
func configureRoutes(gin *ginPlatform.GinInstance, gomicro gmw.GoMicroClientPort) {
	// Obtener el router de Gin
	router := gin.GetRouter()

	// Configurar rutas de usuario
	user.Routes(router)

	// Configurar rutas de monitoreo
	monitoring.Routes(gin, gomicro)

	// Registrar el router en el servicio Go Micro
	gomicro.GetService().Handle("/", router)
}
