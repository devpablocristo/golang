package main

import (
	"log"

	monitoring "github.com/devpablocristo/golang/sdk/cmd/rest/monitoring/routes"
	user "github.com/devpablocristo/golang/sdk/cmd/rest/user/routes"
	consulsetup "github.com/devpablocristo/golang/sdk/internal/platform/consul"
	gingonicsetup "github.com/devpablocristo/golang/sdk/internal/platform/gin"
	gmwsetup "github.com/devpablocristo/golang/sdk/internal/platform/go-micro-web"
	basesetup "github.com/devpablocristo/golang/sdk/pkg/base-setup"
)

func main() {
	if err := basesetup.InitSetup(); err != nil {
		log.Fatalf("Error setting up configurations: %v", err)
	}
	basesetup.LogInfo("Application started with JWT secret key: %s", basesetup.GetJWTSecretKey())
	basesetup.MicroLogInfo("Starting application...")

	consul, err := consulsetup.NewConsulInstance()
	if err != nil {
		basesetup.MicroLogError("error initializing Consul: %v", err)
	}

 00	gomicro, err := gmwsetup.NewGoMicroInstance(consul)
	if err != nil {
		basesetup.MicroLogError("error initializing Go Micro: %v", err)
	}

	gingonic, err := gingonicsetup.NewGinInstance()
	if err != nil {
		basesetup.MicroLogError("error initializing Gin: %v", err)
	}

	monitoring.Routes(gingonic, gomicro)

	r := gingonic.GetRouter()

	user.Routes(r)

	gomicro.GetService().Handle("/", r)

	if err := gomicro.GetService().Run(); err != nil {
		basesetup.MicroLogError("error starting GoMicro service: %v", err)
	}
}
