package main

import (
	"log"

	monitoring "github.com/devpablocristo/golang/sdk/cmd/rest/monitoring/routes"
	user "github.com/devpablocristo/golang/sdk/cmd/rest/user/routes"
	consulsetup "github.com/devpablocristo/golang/sdk/internal/platform/consul"
	ginsetup "github.com/devpablocristo/golang/sdk/internal/platform/gin"
	gmwsetup "github.com/devpablocristo/golang/sdk/internal/platform/go-micro-web"
	initialsetup "github.com/devpablocristo/golang/sdk/pkg/initial-setup"
)

func main() {
	if err := initialsetup.InitSetup(); err != nil {
		log.Fatalf("Error setting up configurations: %v", err)
	}
	initialsetup.LogInfo("Application started with JWT secret key: %s", initialsetup.GetJWTSecretKey())
	initialsetup.MicroLogInfo("Starting application...")

	consul, err := consulsetup.NewConsulInstance()
	if err != nil {
		initialsetup.MicroLogError("error initializing Consul: %v", err)
	}

	gomicro, err := gmwsetup.NewGoMicroInstance(consul)
	if err != nil {
		initialsetup.MicroLogError("error initializing Go Micro: %v", err)
	}

	gingonic, err := ginsetup.NewGinInstance()
	if err != nil {
		initialsetup.MicroLogError("error initializing Gin: %v", err)
	}

	monitoring.Routes(gingonic, gomicro)

	r := gingonic.GetRouter()

	user.Routes(r)

	gomicro.GetService().Handle("/", r)

	if err := gomicro.GetService().Run(); err != nil {
		initialsetup.MicroLogError("error starting Gin server: %v", err)
	}

}
