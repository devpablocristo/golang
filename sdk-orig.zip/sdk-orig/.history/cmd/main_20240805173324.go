package main

import (
	"log"

	// Importar paquetes necesarios
	monitoring "github.com/devpablocristo/golang/sdk/cmd/rest/monitoring/routes"
	user "github.com/devpablocristo/golang/sdk/cmd/rest/user/routes"
	consulsetup "github.com/devpablocristo/golang/sdk/internal/platform/consul"
	gingonicsetup "github.com/devpablocristo/golang/sdk/internal/platform/gin"
	gmwsetup "github.com/devpablocristo/golang/sdk/internal/platform/go-micro-web"
	basesetup "github.com/devpablocristo/golang/sdk/pkg/base-setup"

	cnsul "github.com/devpablocristo/golang/sdk/pkg/consul"
	gingonic "github.com/devpablocristo/golang/sdk/pkg/gin-gonic/gin"
	gmw "github.com/devpablocristo/golang/sdk/pkg/go-micro-web"
)

func main() {
	// Inicializar configuración de la aplicación
	if err := basesetup.InitSetup(); err != nil {
		log.Fatalf("Error setting up configurations: %v", err)
	}
	basesetup.LogInfo("Application started with JWT secret key: %s", basesetup.GetJWTSecretKey())
	basesetup.MicroLogInfo("Starting application...")

	// Inicializar los servicios principales
	consul, goMicro, ginInstance, err := initializeServices()
	if err != nil {
		basesetup.MicroLogError("Failed to initialize services: %v", err)
		return
	}

	// Configurar rutas
	configureRoutes(ginInstance, goMicro)

	// Ejecutar el servicio Go Micro
	if err := goMicro.GetService().Run(); err != nil {
		basesetup.MicroLogError("Error starting Go Micro server: %v", err)
	}
}

// initializeServices inicializa Consul, Go Micro y Gin
func initializeServices() (consul.ConsulClientPort, gmw.GoMicroClientPort, *gingonic.GinClientPort, error) {
	// Inicializar Consul
	consul, err := consulsetup.NewConsulInstance()
	if err != nil {
		return nil, nil, nil, err
	}

	// Inicializar Go Micro
	goMicro, err := gmwsetup.NewGoMicroInstance(consul)
	if err != nil {
		return nil, nil, nil, err
	}

	// Inicializar Gin
	ginInstance, err := gingonicsetup.NewGinInstance()
	if err != nil {
		return nil, nil, nil, err
	}

	return consul, goMicro, ginInstance, nil
}

// configureRoutes configura las rutas de la aplicación
func configureRoutes(ginInstance *gingonicsetup.GinInstance, goMicro gmwsetup.GoMicroClientPort) {
	// Configurar rutas de monitoreo
	monitoring.Routes(ginInstance, goMicro)

	// Obtener el router de Gin
	router := ginInstance.GetRouter()

	// Configurar rutas de usuario
	user.Routes(router)

	// Registrar el router en el servicio Go Micro
	goMicro.GetService().Handle("/", router)
}
