package main

import (
	"log"

	is "github.com/devpablocristo/golang/sdk/pkg/init-setup"

	//arts "github.com/devpablocristo/golang/sdk/cmd/rest/auth/routes"
	monitoring "github.com/devpablocristo/golang/sdk/cmd/rest/monitoring/routes"
	//nrts "github.com/devpablocristo/golang/sdk/cmd/rest/nimble-cin7/routes"

	//csd "github.com/devpablocristo/golang/sdk/internal/platform/cassandra"
	cnsl "github.com/devpablocristo/golang/sdk/internal/platform/consul"
	gin "github.com/devpablocristo/golang/sdk/internal/platform/gin"
	gmw "github.com/devpablocristo/golang/sdk/internal/platform/go-micro-web"

	//mysql "github.com/devpablocristo/golang/sdk/internal/platform/mysql"
	//pgts "github.com/devpablocristo/golang/sdk/internal/platform/postgresql/pqxpool"
	//redis "github.com/devpablocristo/golang/sdk/internal/platform/redis"
	//stg "github.com/devpablocristo/golang/sdk/internal/platform/stage"

	user "github.com/devpablocristo/golang/sdk/cmd/rest/user/routes"
)

func main() {
	if err := is.InitSetup(); err != nil {
		log.Fatalf("Error setting up configurations: %v", err)
	}
	is.LogInfo("Application started with JWT secret key: %s", is.GetJWTSecretKey())
	is.MicroLogInfo("Starting application...")

	// TODO: Probar stage
	// stage
	// if _, err := stg.NewStageInstance(); err != nil {
	// 	is.MicroLogError("error initializing Stage: %v", err)
	// }

	consul, err := cnsl.NewConsulInstance()
	if err != nil {
		is.MicroLogError("error initializing Consul: %v", err)
	}

	gomicro, err := gmw.NewGoMicroInstance(consul)
	if err != nil {
		is.MicroLogError("error initializing Go Micro: %v", err)
	}

	gingonic, err := gin.NewGinInstance()
	if err != nil {
		is.MicroLogError("error initializing Gin: %v", err)
	}

	monitoring.Routes(gingonic, gomicro)

	r := gingonic.GetRouter()

	user.Routes(r)

	gomicro.GetService().Handle("/", r)

	if err := gomicro.GetService().Run(); err != nil {
		is.MicroLogError("error starting Gin server: %v", err)
	}

}
