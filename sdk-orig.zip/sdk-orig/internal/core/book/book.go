package book

type Book struct {
	ID     int
	Title  string
	Author string
	Year   string
}
