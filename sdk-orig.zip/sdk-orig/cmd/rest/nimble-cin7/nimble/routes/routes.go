package nimble

import (
	"github.com/gin-gonic/gin"
	// wire "github.com/devpablocristo/golang/sdk/cmd/rest"
	// is "github.com/devpablocristo/golang/sdk/pkg/init-setup"
)

func Routes(r *gin.Engine) {
	// handler, err := wire.InitializeNimbleHandler()
	// if err != nil {
	// 	is.MicroLogError("nimHandler error: %v", err)
	// }

	// r.GET("/nimble-ping", handler.NimblePing)
	// r.POST("/order-shipment", handler.OrderShipment)
}
