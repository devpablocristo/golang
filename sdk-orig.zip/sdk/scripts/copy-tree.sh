#!/bin/bash

tree | xclip -selection clipboard
