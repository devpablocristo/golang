package authroutes

// "github.com/gin-gonic/gin"

// wire "github.com/devpablocristo/golang/sdk/cmd/rest"
// is "github.com/devpablocristo/golang/sdk/pkg/init-setup"

// func AuthRoutes(r *gin.Engine) {
// 	authHandler, err := wire.InitializeAuthHandler()
// 	if err != nil {
// 		is.MicroLogError("authHandler error: %v", err)
// 	}

// 	api := r.Group("/api/v1")
// 	{
// 		api.POST("/login", authHandler.Login)
// 	}
// }
