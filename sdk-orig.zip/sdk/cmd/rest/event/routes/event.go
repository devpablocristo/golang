package event

import (
	"github.com/gin-gonic/gin"
)

func Routes(r *gin.Engine) {
	// r.POST("/events", r.CreateEvent)
	// r.DELETE("/events/:eventID", r.DeleteEvent)
	// r.DELETE("/events/hard/:eventID", r.HardDeleteEvent)
	// r.PATCH("/events/:eventID", r.UpdateEvent)
	// r.PATCH("/events/revive/:eventID", r.ReviveEvent)
	// r.GET("/events/:eventID", r.GetEvent)
	// r.GET("/events", r.GetAllEvents)
}
