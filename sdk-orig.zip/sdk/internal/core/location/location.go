package location

type Location struct {
	Address    string
	City       string
	State      string
	Country    string
	PostalCode string
}

