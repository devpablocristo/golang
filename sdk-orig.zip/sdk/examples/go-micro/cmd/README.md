go-micro, consul (con go-micro), gin, mapdb

auth rest server (username, passwordhash) -> auth usecases -> auth client grpc  -> user server grpc -> auth client grpc -> auth client grpc -> auth rest server 