package entities

type Location struct {
	Address    string
	City       string
	State      string
	Country    string
	PostalCode string
}

