comandos utiles 
crtl k ctrl q - ultima edicion
crtl alt - ultimas adiciones para atras
ctil shift - utimas edicione spara adealante