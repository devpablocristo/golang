package shared

type Item struct {
	ItemID   string
	Quantity int
}
